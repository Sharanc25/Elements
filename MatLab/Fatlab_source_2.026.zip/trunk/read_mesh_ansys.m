function [node_table,elem_table,elem_types] = read_mesh_ansys(file)

    n_lines = size(file,1);

    % initialize arrays
    node_table = zeros(n_lines,4,'single');  % nodeno, x,y,z coordinates
    elem_table = zeros(n_lines,11,'single'); % elemno, typeno, matno, up to 8 nodes
    elem_types = zeros(n_lines,1,'uint16');
    
    % scan line by line and extract values
    nn = 0;
    ne = 0;

    in_node_block = false;
    in_elem_block = false;
    i = 0;
    
    while i < n_lines

        i = i+1;
        cur_line = file(i,:);

        % element types
        if strncmp(cur_line,' ELEMENT TYPE',13)
            
            type_line = cur_line;
            type_no_line = type_line(15:end);
            [type_no_str,rest] = strtok(type_no_line); 
            type_no = str2single(type_no_str);
            rest(1:3) = [];
            type_name = strtok(rest); 
            
            switch type_name
                case {'SOLID186','SOLID185'} % hex
                    elem_types(type_no) = 2;
                    
                case {'SOLID187'} % tet
                    elem_types(type_no) = 3;
                    
                case {'PLANE42','PLANE82','PLANE182','PLANE183'} % planar
                    elem_types(type_no) = 4;
                    
                case {'SHELL181','SHELL281','SHELL63'} % shells
                    elem_types(type_no) = 5;
                    
                case 'ROUGH' % handle new version 16+ ETLIST print out format:
                    % ELEMENT TYPES      3 THROUGH      5 ARE THE SAME AS TYPE      2   
                    [~,rest] = strtok(rest);
                    [type_no_end_str,rest] = strtok(rest);
                    [~,rest] = strtok(rest);
                    [~,rest] = strtok(rest);
                    [~,rest] = strtok(rest);
                    [~,rest] = strtok(rest);
                    [~,rest] = strtok(rest);
                    [same_type_str,~] = strtok(rest);
                    
                    type_no_end = str2single(type_no_end_str);
                    same_type_no = str2single(same_type_str);
                    
                    for multi_type = type_no:type_no_end
                        elem_types(multi_type) = elem_types(same_type_no); 
                    end
                    
                otherwise % unsupported
                    elem_types(type_no) = 99; 
            end
                    
            continue;
            
        end
        
        
      
        
        % are we out of a block of data?
        if strncmp(cur_line,'         ',9) || strncmp(cur_line,'1',1)
            in_node_block = false;
            %in_elem_block = false;
            continue;
        end

        if in_node_block
            nn = nn+1;
            
            [node_str,rest] = strtok(cur_line);
            [x_str,rest]    = strtok(rest);
            [y_str,rest]    = strtok(rest);
            z_str           = strtok(rest);
            
            node_no = str2single(node_str);
            x = str2single(x_str);
            y = str2single(y_str);
            z = str2single(z_str);
            
            node_table(nn,1:4) = [node_no x y z];
            continue;
        end

        if strncmp(cur_line,'   NODE',7)
            in_node_block = true;
            continue;
        end

        

        % elements
        if strncmp(cur_line,'                                   ',35)...
        || strncmp(cur_line,'1',1)
            in_elem_block = false;
        end

        if in_elem_block && ~strncmp(cur_line,'        ',8) 
            % ELEM MAT TYP REL ESY SEC    NODES
            % 316   4   4   1   0   4     74   444   443    75   370   251   252   371

            [elem_no_str,rest] = strtok(cur_line); % elem no
            [cur_mat_str,rest] = strtok(rest); % eleme MAT no.
            [cur_typ_str,rest] = strtok(rest); % elem TYP no

            elem_no  = str2single(elem_no_str);
            cur_mat  = str2single(cur_mat_str);
            cur_type = str2single(cur_typ_str);
            
            if elem_no>0 && elem_types(cur_type)>0

                ne = ne+1;
                elem_table(ne,1) = elem_no;
                elem_table(ne,2) = cur_type;
                elem_table(ne,3) = cur_mat;

                switch elem_types(cur_type)
                    case 2 % hex
                        nodes_per_element = 8;

                    case {3,4,5} % tet/plane/shell
                        nodes_per_element = 4;
                        
                    otherwise 
                        nodes_per_element = 0; % to satisfy coder
                end

                for skip=1:3
                    [~,rest] = strtok(rest);
                end
                
                for n = 1:nodes_per_element
                    [node,rest] = strtok(rest);
                    elem_table(ne,n+3) = str2single(node);
                end

                continue; 
            end
            
        end

        if strncmp(cur_line,'    ELEM',8)
            in_elem_block = true;
            i = i + 1;
            continue;
        end
        
    end

    % remove unused entries
    node_table(node_table(:,1)==0,:) = [];
    elem_table(elem_table(:,1)==0,:) = [];
    elem_types(elem_types==0)        = [];

    
%coder -build read_mesh_ansys.prj