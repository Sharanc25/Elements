function [options,model,FE] = setup_model_nonlinear(options,model,FE)

    global hs
    
    % left, bottom, width, height
    hs.fig = figure('name','Setup model','NumberTitle','off','units','characters','position', [65 15 135 40],...
                    'color',[0.941176 0.941176 0.941176],'windowstyle','modal','WindowKeyPressFcn',@ok_cancel,'Resize','off'); 
    change_icon(hs.fig,'icon.png');
    center_gui(hs.fig);
    pos   = get(hs.fig,'pos');
    top   = pos(4);
    width = pos(3);

    setappdata(hs.fig,'options',options);
    setappdata(hs.fig,'model',model);
    setappdata(hs.fig,'FE',FE);
    setappdata(hs.fig,'selectedFE',1);
    setappdata(hs.fig,'selected_load',1);
        
    % model panel
    hs.pan1   = uipanel('units','characters','pos',[2 top-6.6 width-4 5.5],'title','Model (node/element definitions)');
    hs.txt    = uicontrol('Style','text','String','Model file:','units','characters','pos',[2 2.7 12 1],'parent',hs.pan1,'horizontalalignment','left');
    hs.edit   = uicontrol('Style','edit','String',options.files.model_file,'units','characters','pos',[15 2.5 90 1.5],'parent',hs.pan1,'horizontalalignment','left','backgroundcolor','w');
    hs.mformat= uicontrol('style','popup','string',{'ANSYS' 'Simulation GEO' 'custom CSV'},'pos',[85 0.5 20 1.5],'value',options.files.model_format,'parent',hs.pan1,'backgroundcolor','w');
    hs.browse = uicontrol('Style','pushbutton','string','Browse...','units','characters','pos',[108 2.3 16 1.75],'parent',hs.pan1,'callback',@cb_browse);
    hs.read   = uicontrol('Style','pushbutton','string','Update','units','characters','pos',[108 0.25 16 1.75],'parent',hs.pan1,'callback',@cb_read_model_file);
    hs.txt    = uicontrol('Style','text','String','Format:','units','characters','pos',[75 0.7 10 1],'parent',hs.pan1,'horizontalalignment','left');
    
    hs.txt    = uicontrol('Style','text','String','Edge detection angle limit:','units','characters','pos',[2 0.7 30 1],'parent',hs.pan1,'horizontalalignment','left');
    hs.edge   = uicontrol('Style','edit','String',options.edge_detection,'units','characters','pos',[31 0.5 7 1.5],'parent',hs.pan1,'horizontalalignment','right','backgroundcolor','w','callback',@cb_edge_detection);
    hs.txt    = uicontrol('Style','text','String','degrees','units','characters','pos',[39 0.7 10 1],'parent',hs.pan1,'horizontalalignment','left');
    
    % FE files panel
    hs.pan2 = uipanel('units','characters','pos',[2 5 width-4 27],'title','FE stress files (stress at given load for each load component)');
    top2 = get(hs.pan2,'pos');
    top2 = top2(4);
    hs.txt    = uicontrol('Style','text','String','Format:','units','characters','pos',[2 top2-3 10 1],'parent',hs.pan2,'horizontalalignment','left');
    hs.uformat= uicontrol('style','popup','string',{'ANSYS','Simulation .CSV' 'Simulation .STE' 'custom CSV'},'pos',[12 top2-3.2 20 1.5],'value',options.FE_format,'parent',hs.pan2,'backgroundcolor','w','callback',@cb_FE_format);
    
    % Load components
    for i = 1:length(FE)
        loads_table{i,1} = FE(i).load_name;
        loads_table{i,2} = options.load_types{FE(i).load_type};
    end
        
    b = 0;
    l = 2;
   
    hs.txt    = uicontrol('Style','text','String','Load components:','units','characters','pos',[l b+22. 25 1],'parent',hs.pan2,'horizontalalignment','left');
    columnname   = {'Load' 'Type'};
    columnedit   = [ false   true];
    columnwidth  = {   100     100};
    columnformat = {'char',options.load_types};
    hs.loads     = uitable('ColumnName', columnname,'ColumnFormat', columnformat,'ColumnEditable',columnedit,'parent',hs.pan2,'units','characters',...
                           'ColumnWidth',columnwidth,'pos',[l b+0.5 46.3 21],'data',loads_table,'CellEditCallback',@cb_editLoad,'CellSelectionCallback',@cb_selectLoad);

    % FE files
    hs.FEtxt    = uicontrol('Style','text','String',['FE stress files for: ' FE(1).load_name],'units','characters','pos',[54 b+22  50 1],'parent',hs.pan2,'horizontalalignment','left');
    columnname   = {'Filename' 'Load' 'Variable'};
    columnedit   = [ false  true   true];
    columnwidth  = {    120     60    60};
    columnformat = {'char','numeric','numeric'};
    hs.FEtable = uitable('ColumnName', columnname,'ColumnFormat', columnformat,'ColumnEditable',columnedit,'parent',hs.pan2,'units','characters',...
                         'ColumnWidth',columnwidth,'pos',[54 0.5 58.4 21],'data',[],'CellEditCallback',@cb_edit_table,'CellSelectionCallback',@cb_selectFE);    

    update_FEtable();
                     
	b = 3;
    l2 = 114;
    hs.add    = uicontrol('Style','pushbutton','string','add','units','characters','pos',   [l2 b+17 10 1.65],'parent',hs.pan2,'callback',@cb_add);
    hs.del    = uicontrol('Style','pushbutton','string','delete','units','characters','pos',[l2 b+15 10 1.65],'parent',hs.pan2,'callback',@cb_edit_table);
    hs.parse  = uicontrol('Style','pushbutton','string','parse','units','characters','pos', [l2 b+13 10 1.65],'parent',hs.pan2,'callback',@cb_edit_table);
    hs.up     = uicontrol('Style','pushbutton','string','up','units','characters','pos',    [l2 b+10 10 1.65],'parent',hs.pan2,'callback',@cb_edit_table);
    hs.down   = uicontrol('Style','pushbutton','string','down','units','characters','pos',  [l2 b+8  10 1.65],'parent',hs.pan2,'callback',@cb_edit_table);
                     
    % OK/cancel
    hs.cancel = uicontrol('Style','pushbutton','string','Cancel','units','characters','pos',[116 2 16 1.75],'callback',@cb_cancel);
    hs.ok     = uicontrol('Style','pushbutton','string','OK','units','characters','pos',[98 2 16 1.75],'callback',@cb_ok);
    hs.update = uicontrol('Style','pushbutton','string','Update all','units','characters','pos',[80 2 16 1.75],'callback',@cb_update_all);
    
    set(gcf,'Visible','on');
    drawnow;
    
    hs.ok_pressed = false;
    uicontrol(hs.ok)
    uiwait(hs.fig);

    if hs.ok_pressed
        options = getappdata(hs.fig,'options');
        FE      = getappdata(hs.fig,'FE');
        model   = getappdata(hs.fig,'model');    
        close(hs.fig);
    end
    
end

function ok_cancel(~,event)

    if strcmp(event.Key,'escape')
        cb_cancel();
    elseif strcmp(event.Key,'return')
        %cb_ok();
    end

end

function cb_edge_detection(hObj,~)

    global hs
    options = getappdata(hs.fig,'options');
    options.edge_detection = str2num(get(hObj,'string'));
    setappdata(hs.fig,'options',options);
    
end

function cb_FE_format(hObj,~)

    global hs
    options = getappdata(hs.fig,'options');
    options.FE_format = get(hObj,'value');
    setappdata(hs.fig,'options',options);
    
end

function cb_cancel(~,~)

    global hs
    uiresume(hs.fig);
    close(hs.fig);

end

function cb_ok(~,~)

    global hs
    options = getappdata(hs.fig,'options');
    model   = getappdata(hs.fig,'model');    
    FE      = getappdata(hs.fig,'FE');

    % default list of nodes = all
    model_nodes = cast(model.surf.node_table(:,1),'uint32');
    options.all_nodes = model_nodes;
    options.nodelist  = model_nodes;
    options.nodelisti = (1:length(model_nodes))';

    % get numbers for later use
    options.n_nodes      = length(options.nodelisti);
    options.n_nodes_all  = length(options.all_nodes);
    options.n_faces      = size(model.surf.face_table,1);
    
    n_loads = length(FE);
    n_ULCs  = 0;
    for i=1:n_loads
        n_ULCs = n_ULCs + length(FE(i).ULC);
    end
    options.n_loads = n_loads;
    options.n_ULCs  = n_ULCs;
    
    % arrange FE data for efficient passing to mex-file
    %  load_table   = [load_type fromULC toULC n_ULCs , n_loads] (int8)
    %  ULC_table    = [load_no load_val var_val , n_ULCs] (single)
    %  stress_table = [Sxx Syy Szz Txy Txz Tyz, n_ULCs] (single)

    if n_ULCs>0
        load_table   = zeros(n_loads,4,'int8');
        ULC_table    = zeros(n_ULCs,3,'single');
        node_stress(options.n_nodes).table = zeros(n_ULCs,6,'single');

        hs.wb = waitbar(0.075,'Consolidating FE data...');
        u = 0; % ULC no
        for i = 1:n_loads

            load_table(i,1) = FE(i).load_type;

            for j = 1:length(FE(i).ULC)

                u = u +1;
                waitbar(u/n_ULCs,hs.wb);

                load_table(i,4) = load_table(i,4) + 1; % nULCs

                if load_table(i,4) == 1
                    load_table(i,2) = u; % fromULC
                end
                load_table(i,3) = u; % toULC

                ULC_table(u,:) = [i FE(i).ULC(j).load_val FE(i).ULC(j).var_val];

                for ni = 1:options.n_nodes
                    node_stress(ni).table(u,:) = FE(i).ULC(j).stress(ni,:);
                end

            end
        end

        delete(hs.wb);
        FE(1).load_table  = load_table;
        FE(1).ULC_table   = ULC_table;
        FE(1).node_stress = node_stress;
    end
    
    setappdata(hs.fig,'FE',FE);
    setappdata(hs.fig,'options',options);

    hs.ok_pressed = true;
    uiresume(hs.fig);
    
end

function cb_browse(~,~)
    
    global hs
    options = getappdata(hs.fig,'options');
    
    if exist('last_folder.mat','file')
        load last_folder.mat
    else
        last_folder = '';
    end
        
    [filename,filepath,~] = uigetfile('*.*','Please select model file',options.files.work_folder);

    last_folder = filepath;
    
    try
        save('last_folder.mat','last_folder');
    catch
        % never mind then.
    end
    
    if ~isnumeric(filename)
        model_file = [filepath filename];
        set(hs.edit,'string',model_file);
    end
    
    setappdata(hs.fig,'options',options);
    cb_read_model_file();
    
end

function cb_selectFE(~,event)

    global hs
    if ~isempty(event.Indices)
        selectedFE = event.Indices(1);
        setappdata(hs.fig,'selectedFE',selectedFE);
    end
    
end

function cb_selectLoad(~,event)

    global hs
    FE = getappdata(hs.fig,'FE');
    
    if ~isempty(event.Indices)
        selected_load = event.Indices(1);
        setappdata(hs.fig,'selected_load',selected_load);
        load_comp = FE(selected_load).load_name;
        set(hs.FEtxt,'string',['FE stress files for: ' load_comp]);

        update_FEtable();
        
    end
    
end

function cb_editLoad(~,event)

    global hs
    FE = getappdata(hs.fig,'FE');
    options = getappdata(hs.fig,'options');
    
    if ~isempty(event.Indices)
        selected_load = event.Indices(1);
        load_type = find(ismember(options.load_types,event.NewData));
        FE(selected_load).load_type = load_type;
        
        if load_type==4 %2D interpolation, next "load" must be the 2nd variable
            if length(FE)>selected_load
                FE(selected_load+1).load_type = 5;
                 loads_table = get(hs.loads,'data');
                 loads_table{selected_load+1,2} = options.load_types{5};
                 set(hs.loads,'data',loads_table);
            else
                error('For 2D interpolation, the next "load" must be the 2nd variable');
            end
        end
        
        setappdata(hs.fig,'FE',FE);
        update_FEtable();
    end
    
end

function update_fe_files(~,~)
 
    % read through alle FE stress files again
    
    global hs
    FE    = getappdata(hs.fig,'FE');
    model = getappdata(hs.fig,'model');
    model_nodes = cast(model.surf.node_table(:,1),'uint32');
    all_nodes   = cast(model.entire.node_table(:,1),'uint32');
    
    hs.wb = waitbar(0.075,'Reading FE stress files');
    
    n_files = 0;
    for i=1:length(FE)
        n_files = n_files + length(FE(i).ULC);
    end            
      
    file_no = 0;
    for i=1:length(FE)
        for j=1:length(FE(i).ULC)
            file_no = file_no + 1;            
            filename = FE(i).ULC(j).filename;
            filepath = FE(i).ULC(j).filepath;
            cur_file_str = strrep(filename,'_',' '); % replace underscores
            waitbar(file_no/n_files,hs.wb,['Importing ' cur_file_str]);
            [reduced_stress_table,stress_table] = read_FE_file([filepath filename],model_nodes);
            FE(i).ULC(j).stress = reduced_stress_table;
            FE(i).ULC(j).stress_all = stress_table;
        end
    end
    
    setappdata(hs.fig,'FE',FE);
    delete(hs.wb);
    
end

function cb_update_all(~,~)

    cb_read_model_file();
    update_fe_files();

end

function cb_add(~,~)
    
    global hs
    FE = getappdata(hs.fig,'FE');
    options = getappdata(hs.fig,'options');
    model = getappdata(hs.fig,'model');
    load_no = getappdata(hs.fig,'selected_load');
    
    if isempty(model)
        errordlg('Read model file first.','Error')
        return;
    else
        model_nodes = cast(model.surf.node_table(:,1),'uint32');
        all_nodes   = cast(model.entire.node_table(:,1),'uint32');
    end
   
    if exist('last_folder.mat','file')
        load last_folder.mat
    else
        last_folder = '';
    end
    
    switch options.FE_format
        case [2 4]
            extension_mask = '*.CSV';
        case 3
            extension_mask = '*.STE';
        otherwise % also 1
            extension_mask = '*.*';    
    end
    
    if FE(load_no).load_type<2
        [filenames, filepath] = uigetfile({extension_mask,'FE stress files'},'Select FE stress file',last_folder);
    elseif FE(load_no).load_type<5
        [filenames, filepath] = uigetfile({extension_mask,'FE stress files'},'Select FE stress files',last_folder,'MultiSelect','on');
    else
        errordlg('No FE stress files should be associated with a variable.');
        return;
    end
        
    hs.wb = waitbar(0.075,'Reading FE stress files');
    
    if ~isnumeric(filenames)
        
        last_folder = filepath;
		try 
			save('last_folder.mat','last_folder');
		catch
			% if we dont have write access, never mind then.
		end
		
        if ~iscell(filenames) % only 1 file selected
            filenames = {filenames};
        end
        
        n_files = length(filenames);
        
        for i=1:n_files
            j = length(FE(load_no).ULC) + 1;
            
            if FE(load_no).load_type == 1 && j>1
                errordlg('Select only 1 FE stress file for load-stress relationship type=linear.')
                return;
            elseif FE(load_no).load_type == 2 && j> 2
                errordlg('Select only 2 FE stress file for load-stress relationship type=bilinear.')
                return;
            end

            cur_file_str = strrep(filenames{i},'_',' '); % replace underscores
            
            waitbar(i/n_files,hs.wb,['Importing ' cur_file_str]);
            FE(load_no).ULC(j).filename = filenames{i};
            FE(load_no).ULC(j).filepath = filepath;
            FE(load_no).ULC(j).load_val = 1;
            FE(load_no).ULC(j).var_val  = 0;
            FE(load_no).ULC(j).stress = read_FE_file([filepath filenames{i}],model_nodes);
            FE(load_no).ULC(j).stress_all = read_FE_file([filepath filenames{i}],all_nodes);
            
        end
        
        setappdata(hs.fig,'FE',FE);
        update_FEtable();
        
    end
    
    delete(hs.wb);
    
end

function cb_edit_table(hObj,event)
    
    global hs
    FE = getappdata(hs.fig,'FE');
    no = getappdata(hs.fig,'selectedFE');
    load = getappdata(hs.fig,'selected_load');
    
    if ~isempty(FE(load).ULC)

        switch hObj
            case hs.del
                FE(load).ULC(no) = [];
                no = max(no-1,1);
                
            case hs.up
                if no > 1
                    temp = FE(load).ULC(no-1);
                    FE(load).ULC(no-1) = FE(load).ULC(no);
                    FE(load).ULC(no)   = temp;
                    no = max(no-1,1);
                end
                
            case hs.down
                if no < length(FE(load).ULC)
                    temp = FE(load).ULC(no+1);
                    FE(load).ULC(no+1) = FE(load).ULC(no);
                    FE(load).ULC(no)   = temp;
                    no = no+1;
                end
                
            case hs.FEtable % user changed load/variable
                if event.Indices(2) == 2
                    FE(load).ULC(no).load_val = event.NewData;
                elseif event.Indices(2) == 3
                    FE(load).ULC(no).var_val = event.NewData;
                end
                
            case hs.parse
                for i = 1:length(FE(load).ULC)
                    [~, filename] = fileparts(FE(load).ULC(i).filename);
                    split = strsplit(filename,'_');
                    if length(split)>1
                        FE(load).ULC(i).load_val = str2num(split{2});
                    end
                    if length(split)>2
                        FE(load).ULC(i).var_val = str2num(split{3});
                    end
                end
                
        end
        
        setappdata(hs.fig,'selectedFE',no);
        setappdata(hs.fig,'FE',FE);
        
        update_FEtable();
        
    end
    
end

function update_FEtable()

    global hs
    FE = getappdata(hs.fig,'FE');
    load = getappdata(hs.fig,'selected_load');

    nULC = length(FE(load).ULC);
    FEtable = [];

    % fill table
    for i = 1:nULC

        FEtable{i,1} = FE(load).ULC(i).filename;
        FEtable{i,2} = FE(load).ULC(i).load_val;

        if FE(load).load_type==4
            FEtable{i,3} = FE(load).ULC(i).var_val;
        end

    end

    set(hs.FEtable,'data',FEtable);
    
end

function cb_read_model_file(~,~)

    global hs
    options = getappdata(hs.fig,'options');
        
    % update gui & load file
    model_file = get(hs.edit,'string');
    
    if isempty(model_file)
        errordlg('Enter/browse for model file first.','Error')
        return;
    end
    
    hs.wb = waitbar(0.075,'Reading input...');
    options.files.model_file  = model_file;
    options.files.work_folder = fileparts(model_file);
    fprintf(1,'Reading input file: %s\n',model_file);
    
    % read model & unit stress files
    options.files.model_format = get(hs.mformat,'value');
    switch options.files.model_format
        case 1; format = 'ANSYS';
        case 2; format = 'SIMULATION';
        case 3; format = 'CUSTOM';
    end
        
    try
        model = read_mesh(options.files.model_file,format,options.edge_detection);
        options.normals = model.surf.node_normals;
    
        if size(model.surf.node_table,1)>1
            fprintf(1,'Model file read successfully.\n');
            setappdata(hs.fig,'model',model);
        else
            errordlg('No nodes read, check model file.','Error');
            return
        end
    catch ME
        
        [~,~,ext] = fileparts(model_file);
        if strcmpi(ext,'.geo') && options.files.model_format==1
            errordlg('Model import failed. Check model format.','Error');
        else
            errordlg('Model import failed. Check inputs.','Unknown error');
        end
        rethrow(ME);
    end
    
    % return data
    setappdata(hs.fig,'options',options);

    delete(hs.wb);
    uicontrol(hs.ok)
    
end

function [reduced_stress_table,stress_table] = read_FE_file(fullfile,model_nodes)
% Import FE stress file

    global hs
    options = getappdata(hs.fig,'options');
    
    switch options.FE_format
        case 1 %'ansys'
            stress_table = read_ansys_stress_files(fullfile,true);

        case 2 %'simulation'
            stress_table = single(csvread(fullfile,5));

            % switch Txz and Tyz to be consistent with ANSYS export
            Txz = stress_table(:,5);
            Tyz = stress_table(:,6);
            stress_table(:,5) = Tyz;
            stress_table(:,6) = Txz;

        case 3 % simulation .STE
            stress_table = read_simulation_ste_file(fullfile);

            % switch Txz and Tyz to be consistent with ANSYS export
            Txz = stress_table(:,5);
            Tyz = stress_table(:,6);
            stress_table(:,5) = Tyz;
            stress_table(:,6) = Txz;
            
        case 4 % custom csv format
            stress_table = single(csvread(fullfile,1));

    end

    FE_nodes = cast(stress_table(:,1),'uint32');
    used_nodes_idx = ismember(FE_nodes,model_nodes);
    FE_nodes = FE_nodes(used_nodes_idx);
    
    %stress_only = stress_table(used_nodes_idx,2:7);
    reduced_stress_table = stress_table(used_nodes_idx,2:7);

    % check that some nodes are read at all
    if ~exist('FE_nodes','var')
        errordlg('No unit stress nodes read.','Error');
        return;
    end
    
    % verify that FE stress file nodes is subset of model nodes
    common_nodes = ismember(FE_nodes,model_nodes);
    if any(common_nodes==0)
        errordlg('FE stress files nodes must be subset of model nodes.','Error');
        return;
    end

end


