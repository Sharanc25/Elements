clc 
folder = fileparts(which(mfilename));
cd(folder);

update_version;

files = {'*.m','*.mex*','*.prj','*.txt','*.gif','*.png','*.mat','+mouse3D'};

zip_name = ['Fatlab_source_' vers '.zip'];
zip(zip_name,files);
system('move *.zip ..\');

% re-compile mex files: (necessary for running Fatlab in pre-2015aSP1 versions)
% coder -build calc_centroid.prj 
% coder -build calc_com.prj 
% coder -build calc_fatigue_stress.prj 
% coder -build calc_nodal_stresses.prj 
% coder -build calc_stress_nonlinear.prj 
% coder -build edge_detection.prj 
% coder -build face_normals.prj 
% coder -build generate_faces.prj 
% coder -build generate_vector_fields.prj 
% coder -build longest_chord.prj 
% coder -build race_track_filter.prj 
% coder -build Rainflow_full.prj 
% coder -build read_mesh_ansys.prj 
% coder -build read_mesh_simulation.prj 
% coder -build remove_collapsed.prj 
% coder -build Reservoir_counting.prj 
% coder -build section_view.prj 
% coder -build sig2ext.prj
