function stress_table = read_simulation_ste_file(ste_file)
% from http://www.pveng.com/FEA/FEANotes/SWS_FileFormat/SWS_FileFormat.php


    % Reading stress file
    A = fopen(ste_file,'r');
    NodesPerElement = fread(A,1,'long');
    NodesPerElementRecord = fread(A,1,'long');
    ElementsInModel = fread(A,1,'long');
    fseek(A,24,'cof');
    NodesInModel = fread(A,1,'long');
    fseek(A,40,'cof');
    PointerToElements = fread(A,1,'long');
    fseek(A,PointerToElements+32,'cof');

    % read block of stress results
    SinglesPerElem = (320+320+116)/4; % 189 singles
    ElemTable = fread(A,[SinglesPerElem,ElementsInModel],'single');
    ElemTableCornerNodes = single(ElemTable(1:32,:)); % stress results for corner nodes only
    fclose(A);
    
    stress_table = calc_nodal_stresses_mex(ElemTableCornerNodes);
    
end
