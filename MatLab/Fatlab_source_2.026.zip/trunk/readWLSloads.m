function loads = readWLSloads(wtg_size,load_type,load_path,varargin)
% Returns WLS loads (in kN/kNm at LAC) read from FAST files (.out) 
% or computed as single cycle loads
%
% Inputs:  Required inputs:
%          wtg_size  (string) '5MW','6MW','8MW','10MW' : turbine size (loads for single nacelle test)
%                             'WLS' : WLS loads (HALT/DEL/MAX only. loads for test of all nacelles in WLS life) 
%                             'ALL' : loads for all turbines as multiple load cases (DEL only).
%
%          load_type (string) 'WIND': simulated wind loads
%                             'HALT': scaled/filtered wind loads for HALT
%                             'DEL' : damage equivalent loads @ 2,000,000 cycles
%                             'MAX' : maximum WLS loads (WLS only)
%
%          Optional property/value pairs:
%          'DELcycles' : (int) Number of cycles at which the DEL is calculated.
%                        Default value = 2000000
%          'Period'    : (float) Period in seconds of single cycle (DEL/MAX) loads.
%                        Default value = 10
%          'nSamples'  : (int) Number of samples in single cycle loads.
%                        Default value = 60
% 
% Outputs: loads(i).t         [jx1] (single: time vector)
%                  .L         [jx6] (single: load matrix)
%                  .Lcomps    {1x6} (cell array of strings: load components)
%                  .Lunits    {1x6} (cell array of strings: load units)
%                  .n         (int: number of repetitions of load case i)
%                  .desc      (string: description of load case, e.g. wind speed)
%                  .wtg_size  (string: same as input)
%                  .load_type (string: same as input)
%                  .prob      (float: fraction of life spent in LC)
%
%                  i is the number of load cases, j is number of samples.
    
%load_path = fileparts(which(mfilename));

% check inputs
if rem(length(varargin),2)
    error('Error: Optional inputs must come in pairs.');
elseif ~any(strcmpi(wtg_size,{'5MW','6MW','8MW','10MW','WLS','ALL'}))
    error('Error: Unknown WTG size specified.');
elseif ~any(any(strcmpi(load_type,{'WIND','HALT','HALT2','DEL','MAX'})))
    error('Error: Unknown load type specified.');
% elseif strcmpi(wtg_size,'WLS') && ~strcmpi(wtg_size,{'MAX','DEL','HALT'})
%     error('Error: MAX loads only available for WLS.');
end

% set default values
DELcycles = 2e6;
Period    = 10;
nSamples  = 60;
rotate_loads = false;

% get optional inputs
for i = 1:2:length(varargin)
    
    property = lower(varargin{i});
    value    = varargin{i+1};
    
    switch property
        case 'delcycles'
            DELcycles = value;
        case 'period'
            Period    = value;
        case 'nsamples'
            nSamples  = value;
        case 'rotate'
            rotate_loads = true;
            C = strsplit(value,',');
            rotation_axis = C{1};
            rotation_rpm = str2num(C{2});

        otherwise
            error('Error: Unknown optional input.')
    end
    
end

% load from files
cur_path = cd;
file_path = [load_path '\' load_type '_' wtg_size];
cd(file_path)
files = dir('*.out');
n_files = length(files);
cd(cur_path)

load_constants;
w = find(ismember({'5MW','6MW','8MW','10MW' 'WLS' 'ALL'},wtg_size));

hw = waitbar(0,'Importing FAST files');

% read files one by one
for f = 1:n_files

    cur_file = [file_path '\' files(f).name];

    % get number of channels
    fid = fopen(cur_file);
    for l = 1:8
        line = fgetl(fid);
        if l == 7
            channels = strtrim(strsplit(line,' '));
        end
    end
    
    % remove 'blank' channel header
    idx = ismember(channels,''); 
    channels = channels(~idx);
    n_channels = length(channels);

    % then read rest of file
    temp = textscan(fid,repmat('%f ',1,n_channels),'CollectOutput',1);
    Lmat = temp{1};
    idx = 2:7;

    % get LC repetitions
    switch load_type
        case 'WIND'
            n = rep;
            prob = p;
        case 'HALT'
            if w<5 % WTG
                n = (T_HALT(w)/T_WTG)*rep;
                prob = p;
            else % WLS 
                n = [];
                prob = [];
                for i = 1:4
                    n = [n (T_HALT(i)/T_WTG)*rep*WTGrep(i)];
                    prob = [prob p/4];
                end
            end
        case 'DEL'
            if strcmpi(wtg_size,'ALL')
                n = 2e6*WTGrep;
                prob = WTG_frac;
            else
                n = Neq(w);
                prob = 1;
            end
        case 'MAX'
            n = repmat(5000,6,1);
            prob = ones(6,1);
    end

    % return data
    switch load_type
        case {'WIND','HALT' 'MAX'}
            loads(f).desc = files(f).name(1:end-4);
        case 'DEL'
            loads(f).desc = [wtg_size '_' load_type];
            if strcmpi(wtg_size,'ALL')
                loads(f).desc = [WTGs{f} '_DEL'];
            end
    end
    loads(f).Lcomps    = {'Fx' 'Fy' 'Fz' 'Mx'  'My'  'Mz'};
    loads(f).Lunits    = {'kN' 'kN' 'kN' 'kNm' 'kNm' 'kNm'};
    loads(f).n         = n(f);
    loads(f).t         = single(Lmat(:,1));
    loads(f).L         = single(Lmat(:,idx));
    loads(f).wtg_size  = wtg_size;
    loads(f).load_type = load_type;
    loads(f).prob      = prob(f);

    fclose(fid);
    waitbar(f/n_files,hw);

end

delete(hw);


% rotating loads, e.g. for mainshaft
if rotate_loads
    
    switch rotation_axis
        case 'x'
            s = [1 0 0]';
        case 'y'
            s = [0 1 0]';
        case 'z'
            s = [0 0 1]';
    end
    
    % angular velocity [rad/s]
    w = 2*pi*rotation_rpm/60;
    
    for lc = 1:length(loads)
    
        F = loads(lc).L(:,1:3);
        M = loads(lc).L(:,4:6);
        
        Fr = F*0;
        Mr = M*0;
        
        for t = 1:length(loads(lc).t)
    
            % instantaneous angle
            theta = loads(lc).t(t) * w;
            
            Ft = F(t,:)';
            Mt = M(t,:)';
            
            Fr(t,:) = rodrigues_rotate(Ft,s,theta)';
            Mr(t,:) = rodrigues_rotate(Mt,s,theta)';
            
        end
        
        % overwrite
        loads(lc).L = [Fr Mr];
        loads(lc).desc = [loads(lc).desc ' rotated around ' rotation_axis ' @ ' num2str(rotation_rpm) 'rpm'];
        
    end
    
end

