function results = fatigue_calc(FE,LC,SN,options,model,results,run_nodes)
% fatigue calculations
warning('off','MATLAB:mir_warning_maybe_uninitialized_temporary');

stress_mode = options.stress_mode;
multi       = options.multi;
n_nodes_all = options.n_nodes_all;
n_nodes_run = length(run_nodes);
n_lc        = length(LC);

% get no. search planes for critical plane analysis
if strcmpi(stress_mode,'CP   ')
    n_planes = options.multi.n_planes(1)*options.multi.n_planes(2);
else
    n_planes = 1;
end

% initialize result arrays 
D     = zeros(n_nodes_all,n_lc,n_planes);
Ntot  = zeros(n_nodes_all,1);
Smin  = zeros(n_nodes_all,n_lc);
Smax  = zeros(n_nodes_all,n_lc);
dSeqi = zeros(n_nodes_all,n_planes);
dSeq  = zeros(n_nodes_all,1);
dSeq1 = zeros(n_nodes_all,1);
dSeq2 = zeros(n_nodes_all,1);

% Arrays for storing results for 
rD     = zeros(n_nodes_run,n_lc,n_planes);
rNtot  = zeros(n_nodes_run,1);
rSmin  = zeros(n_nodes_run,n_lc);
rSmax  = zeros(n_nodes_run,n_lc);
rdSeqi = zeros(n_nodes_run,n_planes);

% create waitbar
step_size = max(floor(n_nodes_run/100),1);


if options.toolbox_parallel_computing == 0 || options.n_cores == 1
    
    % waitbar with abort option
    hwb = awaitbar(0,'Performing fatigue analysis, please wait...');
    
    for i = 1:n_nodes_run
        
        % update waitbar
        if mod(i,step_size)==0
           abort = awaitbar(i/n_nodes_run);
           if abort
               return; 
           end	
        end
    
        [rSmin(i,:), rSmax(i,:), rD(i,:,:), rdSeqi(i,:), rNtot(i)] = node_calc(run_nodes(i),FE,LC,SN,stress_mode,multi,n_planes,model,options);
        
    end 
    
    delete(hwb);
    
else
    
    % special waitbar for parallel loop
    ppm = ParforProgMon('Performing fatigue analysis, please wait...', n_nodes_run, step_size, 300, 80);

    parfor i = 1:n_nodes_run
        
        if mod(i,step_size)==0
            ppm.increment();
        end
        
        [rSmin(i,:), rSmax(i,:), rD(i,:,:), rdSeqi(i,:), rNtot(i)] = node_calc(run_nodes(i),FE,LC,SN,stress_mode,multi,n_planes,model,options);
        
    end 
    
    ppm.delete();
    
end

% Copy temporary results to final result arays
for i = 1:n_nodes_run
    ni = run_nodes(i);
    Ntot(ni) = rNtot(i);
    Smin(ni,:) = rSmin(i,:);
    Smax(ni,:) = rSmax(i,:);
    D(ni,:,:) = rD(i,:,:);
    dSeqi(ni,:) = rdSeqi(i,:);
end


% append calculated damage to existing results?
if options.accumulation == 2 
    dSeqi = dSeqi + results.dSeqi; % append results to some variables:
    Ntot  = Ntot  + results.Nload;
    D(:,end+1,:) = results.Dcp; % create fictitious LC for other variables
end


% sum damage over load cases
if strcmpi(stress_mode,'CP   ')
    Dall = D;
    Dlc  = max(D,[],3);
    Dtot = sum(Dlc,2);
    Dcp  = permute(sum(D,2),[1,3,2]); % find critical plane (with max damage)
    [~,cp] = max(Dcp,[],2);
else
    Dall = D;
    Dlc  = D;
    Dtot = sum(D,2);
    Dcp  = Dtot;
    cp   = ones(n_nodes_all,1);
end


if options.accumulation == 2 % delete extra lc again
    Dall(:,end,:) = [];
    Dlc(:,end)    = [];
end


% finish calculate equivalent stress range at zero mean stress (R=-1)
for i = 1:n_nodes_all
    p = cp(i);
    dSeq(i)  = ((1/SN.Dal)*dSeqi(i,p)/Ntot(i))^(1/SN.m1);
    dSeq1(i) = ((1/SN.Dal)*dSeqi(i,p)/SN.N1)^(1/SN.m1);
    dSeq2(i) = ((1/SN.Dal)*dSeqi(i,p)/SN.N2)^(1/SN.m1);
end


% utilization ratio
UR = dSeq2./SN.ds2;

% endurable life
Nlife = Ntot./Dtot;

% return results
results.Dall    = Dall;
results.Dlc     = Dlc;
results.Dtot    = Dtot;
results.Dcp     = Dcp;
results.cp      = cp;
results.UR      = UR;
results.Nload   = Ntot;
results.Nlife   = Nlife;
results.dSeqi   = dSeqi; % not for plotting, but for appending later runs
results.dSeq    = dSeq;
results.dSeq1   = dSeq1;
results.dSeq2   = dSeq2;

% min/max stresses
if options.accumulation == 2
    results.Smin    = [Smin min(min(Smin,[],2),results.Smin(:,end))];
    results.Smax    = [Smax max(max(Smax,[],2),results.Smax(:,end))];
else
    results.Smin    = [Smin min(Smin,[],2)];
    results.Smax    = [Smax max(Smax,[],2)];
end
results.dSmax   = results.Smax-results.Smin;
