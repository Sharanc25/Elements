function B = remrowinfnan(A)
% Remove rows containing Inf and NaN from array A.

rows = size(A,1);
j = 0;
B = [];

for i = 1:rows
    if ~any(isnan(A(i,:))) && ~any(isinf(A(i,:)))
        j = j+1;
        B(j,:) = A(i,:);
    end
end