function v_rot = rodrigues_rotate(v,k,theta)
% Rotates v around k by the angle theta
% using the Rodrigues rotation formula.

v_rot = v*cos(theta) + cross(k,v)*sin(theta) + k*dot(k,v)*(1-cos(theta));

