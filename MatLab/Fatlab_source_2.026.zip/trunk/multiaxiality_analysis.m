function alpha = multiaxiality_analysis(nodesi,FE,L,options,model,mode)
% Investigates the multiaxiality level of the node stresses under the current load case
% returns the angle (alpha) of the numerically largest principal stress.

n_nodes = length(nodesi);
n_steps = length(L);

alpha = zeros(n_nodes,n_steps);

for i = 1:n_nodes

    ni = nodesi(i);
    
    % unit direction vector of the numerically largest principal stress
    pt = calc_stress(ni,FE,L,'Pmdir',options.multi);

    n = model.surf.node_normals(ni,:)'; % surface normal at node (unit vector)
    x = model.surf.node_axis(ni,:)'; % surface tangent plane coordinate system (1st CP plane normal)
    y = cross(n,x);

    % project u on surface tangent plane defined by n and find angle to x
    for t = 1:n_steps

        u = pt(t,:)';
        p = unit(u - dot(u,n)*n); %Pnmax projected on plane

        if dot(p,x)<0
            p = -p;
        end

        alpha(i,t) = real(sign(dot(p,y)) * acos(dot(p,x)));

    end
end

if strcmp(mode,'span')
    alpha = max(alpha,[],2) - min(alpha,[],2);
end
