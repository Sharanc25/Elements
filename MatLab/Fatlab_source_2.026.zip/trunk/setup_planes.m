function [normals,normal_planes,shear_planes] = setup_planes(model,n_planes,nodes)
% Setup cutting planes for critical plane analysis
%
% normals       = surface normals for each node
% normal_planes = planes intersecting surface at 90 degrees
% shear_planes  = planes intersecting surface at +/-45 degrees
    
    faces   = model.surf.face_table(:,1:4);
    coords  = model.surf.node_table(:,2:4);
    n_nodes = length(nodes);
    normals = zeros(n_nodes,3,'single');
    normal_planes = zeros(n_nodes,3*n_planes,'single');
    shear_planes  = zeros(n_nodes,3*n_planes,'single');

    set(gcf,'Pointer','watch'); drawnow;
    for ni = 1:n_nodes
                
        n = nodes(ni);
        faces_on_node = model.surf.mapping.ni2face(n,:);
        faces_on_node = faces_on_node(faces_on_node>0);
        all_nodes     = unique(faces(faces_on_node,:));
        
        % fit plane to all nodes on all faces connected to central node:
        X = coords(all_nodes,:);
        p = mean(X,1);
    
        % The samples are reduced:
        R = bsxfun(@minus,X,p);
        
        % Computation of the principal directions of the samples cloud
        [V,~] = eig(R'*R);
        
        % surface tangent plane normal
        n = V(:,1);

        % fix normal so it points outwards
        if 1
            elems_on_node = model.surf.mapping.ni2ei(ni,:);
            elems_on_node = elems_on_node(elems_on_node>0);
            
            % calculate combined COM of attached elements
            ec = [0 0 0]';
            for i = 1:length(elems_on_node)
                ei = elems_on_node(i);
                ec = ec + model.surf.elem_table(ei,12:14)';
            end
            ec = ec/length(elems_on_node);

            % node position
            np = coords(ni,:)';
            
            % if normal points 
            n1 = np + n;
            n2 = np - n;
            if norm(n1-ec) < norm(n2-ec)
                n = -n;
            end
            
        end
        
        % cutting planes normal to surface
        x = V(:,2);
        normals(ni,:) = real(n');
        normal_planes(ni,:) = rotate_planes(n,x,n_planes);
        
        % shear planes at 45 degrees inclination to surface
        y = cross(n,x);
        x45 = rodrigues_rotate(x,y,pi/4);
        shear_planes(ni,:) = rotate_planes(n,x45,n_planes);

    end
    
    set(gcf,'Pointer','arrow');
    
end
