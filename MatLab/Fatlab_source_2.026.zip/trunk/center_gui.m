function center_gui(fig)

    oldfunits = get(fig, 'Units');
    set(fig, 'Units', 'pixels');
    oldpos = get(fig, 'OuterPosition');

    fwidth  = oldpos(3);
    fheight = oldpos(4);

    old0units = get(0, 'Units');
    set(0, 'Units', 'pixels');
    screensize = get(0, 'ScreenSize');
    set(0, 'Units', old0units);

    swidth = screensize(3);
    sheight = screensize(4);
    
    % make sure the figure is not bigger than the screen size
    fwidth = min(fwidth, swidth);
    fheight = min(fheight, sheight);

    % swidth - fwidth == remaining width
    rwidth  = swidth-fwidth;

    % sheight - fheight == remaining height
    rheight = sheight-fheight;


    newpos = [rwidth/2, rheight/2];
    newpos(3:4) = [fwidth, fheight];

    set(fig, 'OuterPosition', newpos);
    set(fig, 'Units', oldfunits);
end