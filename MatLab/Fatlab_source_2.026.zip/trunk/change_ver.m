function change_ver(prjfile,ver)

% read and change file content
fid = fopen(prjfile,'r');
file    = textscan(fid,'%s','delimiter',sprintf('\n'),'whitespace','');
file    = file{1};

for i = 1:length(file)

    line = file{i};

    % change version no.
    if length(line)>19 && strcmp(line(1:19),'    <param.version>')
        file{i} = ['    <param.version>' ver '</param.version>'];
    end
        
    % change file name
    %'    <param.web.mcr.name>Fatlab_web</param.web.mcr.name>'
    if length(line)>24 && strcmp(line(1:24),'    <param.web.mcr.name>')
        file{i} = ['    <param.web.mcr.name>Fatlab_' ver '</param.web.mcr.name>'];
    end    

end

fclose all;


% write modefied file
fid = fopen(prjfile,'w');

for i = 1:length(file)
    line = file{i};
    fprintf(fid,'%s\n',line);
end

fclose all;