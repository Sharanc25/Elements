function [Smin, Smax, D, dSeqi, Ntot] = node_calc(ni, FE, LC, SN, stress_mode, p_multi, n_planes, model, options)

    n_lc   = length(LC);
    D     = zeros(n_lc,n_planes);
    Ntot  = 0;
    Smin  = zeros(n_lc,1);
    Smax  = zeros(n_lc,1);
    dSeqi = zeros(n_planes,1);

    % multiaxial setup (node specifics)
    p_multi.node_normal = model.surf.node_normals(ni,:)';
    p_multi.node_axis   = model.surf.node_axis(ni,:)';
    
    for lc = 1:n_lc

        % calculate fatigue relevant stress-time series
        Sf = calc_stress(ni,FE,LC(lc).L,stress_mode,p_multi);
        
        for p = 1:n_planes
            
            % get current plane stress-time series
            Sp = Sf(:,p); 
            Smin(lc) = min([Smin(lc) min(Sp)]); % store min/max
            Smax(lc) = max([Smax(lc) max(Sp)]);
            
            % cycle counting
            rf = cycle_counter(Sp,LC(lc).n,options);
            
            % damage accumulation
            D(lc,p) = damage_calc(rf,SN);
            
            % calculate equivalent stress range
            dSeqi(p) = dSeqi(p) + equivalent_stress_bilin(rf,SN);

        end % plane
            
        % count total number of load cycles
        Ntot = Ntot + sum(rf(4,:));

    end % lc
    
end