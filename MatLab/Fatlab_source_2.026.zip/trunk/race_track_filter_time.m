function [filt_peaks,filt_time] = race_track_filter_time( peaks, time, threshold )
    % Use the racetrack-filter algorithm to eliminate small cycles from the list of peaks.

    n_peaks = size(peaks,1);
    
    % only 1 peak -> nothing to filter
    if n_peaks < 2
        filt_peaks = peaks;
        filt_time  = time;
        return
    end
    
    filt_peaks = zeros(n_peaks,1);
    filt_time  = zeros(n_peaks,1);
 
    S1 = peaks(1);
    S2 = peaks(2);
    t1 = time(1);
    t2 = time(2);
    
    i = 2;
    n = 0;

    while i < n_peaks

        i = i + 1;
        S3 = peaks(i);
        t3 = time(i);

        % Calculate the absolute difference between data points.
        d12 = abs(S1 - S2);
        d23 = abs(S2 - S3);
        d31 = abs(S3 - S1);

        % find the greatest difference.  If difference is greater than the threshold
        % value, continue with the algorithm; otherwise go back and get another data point.
        if d12 < threshold
            if d23 >= d12 && d23 >= d31
                S1 = S2;
                t1 = t2;
                S2 = S3;
                t2 = t3;
                if d23 >= threshold
                    break; 
                end
            elseif d31 >= d12 && d31 >= d23 
                S2 = S3;
                t2 = t3;
                if d31 >= threshold
                    break; 
                end
            end
        else
            i = i - 1; % We don't really want to get another data point just yet, so trick it.
            break
        end
    end

    % If Diff32 is greater than the threshold, write s1 to output file and move s1, s2, and s3 forward 
    % in the data file by one. If Diff32 is less than the threshold, points must be discarded.
    while i < n_peaks

        i = i + 1;
        
        S3  = peaks(i);
        t3  = time(i);
        d12 = abs(S1 - S2);
        d23 = abs(S2 - S3);

        if d23 >= threshold
            n = n + 1;
            filt_peaks(n) = S1;
            filt_time(n)  = t1;
            S1 = S2;
            t1 = t2;
            S2 = S3;
            t2 = t3;
        else
            i = i + 1;
            if i > n_peaks; 
            	break; 
            end
            S3 = peaks(i);
            t3 = time(i);

            if abs(S1 - S3) > d12
                S2 = S3; 
                t2 = t3;
            end
        end
    end
    
    filt_peaks(n+1) = S1;
    filt_peaks(n+2) = S2;
    filt_time(n+1) = t1;
    filt_time(n+2) = t2;

    % eliminate unused entries
    filt_peaks(n+3:n_peaks) = [];
    filt_time(n+3:n_peaks) = [];
