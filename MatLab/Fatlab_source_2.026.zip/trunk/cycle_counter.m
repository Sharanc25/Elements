function rf = cycle_counter(S,lc_reps,options)
% perform cycle counting of stress-time history

    if options.multiaxial < 2 % filtering not nessary for advanced multiaxial (only one cycle)
        % extract turning points
        extremes = sig2ext_mex(S);

        % filter away small stress cycles
        if options.racetrack   
            k = single(range(extremes)*options.racetrack);
            if length(extremes)>1
                extremes = race_track_filter_mex(extremes,k);
            end
        end
    end
    
    % cycle counting
    switch options.cycle_count 
        case 1 % Rainflow half
            rf = rainflow_half(double(extremes));
        
        case 2 % Rainflow full 
            rf = rainflow_full_mex(extremes);    
            
        case 3 % Reservoir
            rf = reservoir_counting_mex(extremes);
            
        case 4 % Single cycle
            rf(1,1) = range(S);
            rf(2,1) = mean(S);
            rf(3,1) = 0; 
            rf(4,1) = 1; % cycles
            rf(5,1) = 0;
            
        % for shear stress based multiaxial criteria only:
        case {5,6,7} % Single cycle LC, Single cycle MCC, Single cycle MRH
            
            Sn   = S(:,1);
            Smax = max(Sn);
            Sm   = mean(Sn);
            Sa   = range(Sn)/2;
                        
            switch options.multi.shear_cycles
                case 'LC   '
                    [~,dT] = longest_chord_mex(S(:,2),S(:,3));
                case 'MCC  '
                    
                case 'MRH  '
                    
            end
            
            rf(1,1) = dT;
            rf(2,1) = Sa;
            rf(3,1) = Sm; 
            rf(4,1) = 1;
            rf(5,1) = Smax;
                   
        otherwise
            error('Unknown cycle counting method specified.');
    end
    
    % scale no. cycles by LC repetitions
    rf(4,:) = rf(4,:)*lc_reps;
    
    % make sure to return singles
    rf = single(rf);