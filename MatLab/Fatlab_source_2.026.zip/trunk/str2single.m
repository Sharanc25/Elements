function num = str2single(input_str)
% convert string to single (ready for mex-ing)

    str = strtrim(input_str);
    n_digits = length(str);
    i = 1;
    num = single(0);
    
    % check sign
    if str(1)=='-'
        is_negative = true;
        str(1) = [];
        n_digits = length(str);
    else
        is_negative = false;
    end
    
    % decimals before the comma
    while i<=n_digits && str(i) >= '0' && str(i) <= '9'
        cur_digit = single(str(i)-'0');
        num = num*10 + cur_digit;
        i = i+1;
    end

    % decimals after the comma
    if i<=n_digits && (str(i) == '.' || str(i) == ',')

        i = i+1;

        % decimal part
        decimal = single(0);
        divisor = single(1);

        while i<=n_digits && str(i) >= '0' && str(i) <= '9'
            divisor = divisor * 10;
            decimal = decimal * 10;
            decimal = decimal + single(str(i) - '0');
            i = i+1;
        end
        
        num = num + decimal / divisor;
   
    end

    % scientific notation
    if i<=n_digits && (str(i) == 'e' || str(i) == 'E')
        i = i+1;
        
        is_negative_exp = false;
        exp = single(0);
        
        switch str(i)
            case '-'
                is_negative_exp = true;
                i = i+1;
            case '+'
                i = i+1;
        end
        
        while i<=n_digits && str(i) >= '0' && str(i) <= '9'
            exp = exp * 10;
            exp = exp + single(str(i) - '0');
            i = i+1;
        end
        
        if is_negative_exp
            exp = -exp;
        end
        
        num = num * 10^exp;
    end
    
    % apply sign
    if is_negative 
        num = -num;
    end
    
end