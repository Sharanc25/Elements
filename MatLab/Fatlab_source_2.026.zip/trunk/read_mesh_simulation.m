function [node_table,elem_table,elem_types] = read_mesh_simulation(file)
% Read Solidworks FE geometry export
    
    n_lines = size(file,1);

    % initialize arrays
    node_table = zeros(n_lines,4,'single');  % nodeno, x,y,z coordinates
    elem_table = zeros(n_lines,11,'single'); % elemno, typeno, up to 8 nodes
    elem_types = zeros(n_lines,1,'uint16');
    
    nn = 0;
    ne = 0;
    eg_no = single(1);
    
    % scan line by line and extract values
    for i=1:n_lines

        cur_line = file(i,:);
        
        % element type: ' EGROUP, 1 TETRA10 , 0, 0, 0, 0, 0, 0, 0, 0,'
        if strncmp(cur_line,' EGROUP',7)
            commas    = strfind(cur_line,','); 
            type      = cur_line(commas(1)+1:commas(2)-1); 
            [type_no,rest] = strtok(type); 
            type_no   = str2single(type_no);
            type_name = strtrim(rest);
            
            if strcmp(type_name,'TETRA10');
                elem_types(type_no) =  1; % tet
            else
                disp('Error: unsupported element.')
            end
            continue;
            
        end

        %activate element group: e.g. ' ACTSET EG 1'
        if strncmp(cur_line,' ACTSET EG',10)
            eg_line = cur_line(11:end);
            eg_no   = str2single(eg_line);
            continue;
            
        end

        % nodes: ' ND, 1,     0.039999999     0.050000001    0.0099999998'
        if strncmp(cur_line,' ND,',4)
            nn   = nn+1;
            
            commas    = strfind(cur_line,','); 
            node_no   = str2single(cur_line(commas(1)+1:commas(2)-1));
            
            node_coords = cur_line(commas(2)+1:end);
            [x_str ,rest] = strtok(node_coords);
            [y_str ,rest] = strtok(rest);
            z_str         = strtok(rest);
            
            x = str2single(x_str);
            y = str2single(y_str);
            z = str2single(z_str);
            
            node_table(nn,1:4) = [node_no x y z];
            continue;
            
        end

        % elements: ' EL,     1,  VL      1,  10  1153  1154  1155  1156  6011  6002  6010  6009  6001  5994     0     0     0     0     0     0'
        if strncmp(cur_line,' EL,',4)
            ne = ne+1;
            
            commas    = strfind(cur_line,','); 
            elem_no   = str2single(cur_line(commas(1)+1:commas(2)-1));
            nodes     = cur_line(commas(3)+1:end);
            
            [~,rest] = strtok(nodes);
            [node1_str,rest] = strtok(rest);
            [node2_str,rest] = strtok(rest);
            [node3_str,rest] = strtok(rest);
            node4_str        = strtok(rest);
            
            node1 = str2single(node1_str);
            node2 = str2single(node2_str);
            node3 = str2single(node3_str);
            node4 = str2single(node4_str);
            
            elem_table(ne,1)   = elem_no;
            elem_table(ne,2)   = eg_no; % type no.
            elem_table(ne,3)   = eg_no; % material no = type no
            elem_table(ne,4:7) = [node1 node2 node3 node4];
            continue;

        end
    end
    
    % remove unused entries
    node_table(node_table(:,1)==0,:) = [];
    elem_table(elem_table(:,1)==0,:) = [];
    elem_types(elem_types==0) = [];
    
end

%coder -build read_mesh_simulation.prj