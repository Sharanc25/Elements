function [str,val]= get_current_popup_string(hh)

    list = get(hh,'String');
    val = get(hh,'Value');
    if iscell(list)
       str = list{val};
    else
       str = list(val,:);
    end
    
    %str = lower(str);
end