function [St,Smin,Smax] = stress_time_plot(nodes,FE,L,stress_type,options)

    n_nodes = length(nodes);
    n_step  = size(L,1);
    
    St = zeros(n_nodes,n_step);
    
    %set(gcf,'Pointer','watch'); drawnow;    
    step_size = floor(n_nodes/100);
    hwb = awaitbar(0,'Calculating stress-time series...');

    for i = 1:n_nodes
        
        node    = nodes(i);
        St(i,:) = calc_stress(node,FE,L,stress_type,options.multi)';
        
        % update waitbar
        if mod(i,step_size)==0
            abort = awaitbar(i/n_nodes);
            if abort; 
                St   = zeros(n_nodes,n_step);
                Smin = zeros(n_nodes,n_step);
                Smax = zeros(n_nodes,n_step);
                return; 
            end	
        end
        
    end
    
    for i = 1:n_nodes
        if i==1
            Smin = min(St(i,:));
            Smax = max(St(i,:));
        else
            Smin = min(Smin,min(St(i,:)));
            Smax = max(Smax,max(St(i,:)));
        end
    end
    
    %set(gcf,'Pointer','arrow');
    delete(hwb);
    
end
