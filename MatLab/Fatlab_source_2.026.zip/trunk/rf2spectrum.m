function [branges,bcycles,ccycles,Sp,Np] = rf2spectrum(ranges,cycles,n_bins)
% Bin rainflow counted data. 
% branges = range bins (up-to value)
% bcycles = binned cycles
% ccycles = cumulative binned cycles


if length(ranges)>n_bins % not just few cycles
    
    % initialize
    rmax = max(ranges);
    branges = linspace(rmax/n_bins,rmax,n_bins);
    bcycles = zeros(n_bins,1);
    ccycles = zeros(n_bins,1);

    % bin cycles according to range
    for r = 1:length(ranges)
        i = find(ranges(r)<branges,1);
    %     i = ceil(ranges(r)/bin_width);
        bcycles(i) = bcycles(i) + cycles(r);
    end

    % flip to largest stress bin first
    branges = flipud(branges');
    bcycles = flipud(bcycles);

    % accumulate cycles
    ccycles(1) = bcycles(1);
    for c = 2:length(bcycles)
        ccycles(c) = bcycles(c) + ccycles(c-1);
    end

    % make plot-ready vectors
    N = ccycles;
    S = branges;
    Np = 1e3;
    Sp = [];
    for i = 1:length(N)
        Np = [Np N(i) N(i)];
        Sp = [Sp S(i) S(i)];
    end

    Sp(end+1) = 1;

else % few cycles only: do not bin
    
    % sort ranges in descending order
    [branges,idx] = sort(ranges,'descend');
    bcycles = cycles(idx);
    
    % accumulate cycles
    ccycles(1) = bcycles(1);
    for c = 2:length(bcycles)
        ccycles(c) = bcycles(c) + ccycles(c-1);
    end
    
    % arrange for plotting
    N = ccycles;
    S = branges;
    Np = 1e3;
    Sp = [];
    for i = 1:length(N)
        Np = [Np N(i) N(i)];
        Sp = [Sp S(i) S(i)];
    end

    Sp(end+1) = 1;

end