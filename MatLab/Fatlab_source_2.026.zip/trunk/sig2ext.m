function ext = sig2ext(S)%#codegen
% extract list of extrema from signal S

n_steps = size(S,1);
ext = zeros(n_steps,1,'single');
ext(1) = S(1);
j = 1;

for i = 2:(n_steps-1)
    
    if (S(i)>S(i-1) && S(i)>S(i+1)) ...
    || (S(i)<S(i-1) && S(i)<S(i+1)) ...
    || (i<n_steps-2 && S(i)==S(i+1) && (S(i)>S(i-1) && S(i)>S(i+2))) ...
    || (i<n_steps-2 && S(i)==S(i+1) && (S(i)<S(i-1) && S(i)<S(i+2)))

        j = j+1;
        ext(j) = S(i);
        
    end;
    
end;

% keep last entry
ext(j+1) = S(end);

% remove unused entries
ext(j+2:end) = [];

% coder -build sig2ext.prj