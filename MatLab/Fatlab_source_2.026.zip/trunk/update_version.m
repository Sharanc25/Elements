clc;
clear all;

% get version
[s,r]=system('svnversion -n');
if strcmp(r(end),'M')
    r(end) = [];
end
R = strsplit(r,':');
r = R{end};
rev = str2double(r);
vers = sprintf('2.%03d',rev);
save vers vers

% fid = fopen('vers.m','w');
% fprintf(fid,'%s',vers);
% fclose(fid);