function rf = reservoir_counting(S) %#codegen
% Reservoir cycle counting, after Maddox (1991):
% - rearrange waveform (S), so that it starts at the highest peak
% - add preceeding cycles to end, such that S also ends with the highest peak
% - fill waveform with water
% - subsequently drain each valley starting with the lowest

% break if signal is flat
if max(S)==min(S)
    rf = single([0; 0; 0; 0; 0]);
    return;
end

% find max peak and shift preceeding cycles
[~,imax] = max(S);
Ss = [S(imax:end); S(1:imax)];

% avoid repeated values; confuses findpeaks()
Ss = fix_repeated_values(Ss);

% find valleys = no. cycles
[~, tvalleys] = findpeaks(-Ss);
valleys = Ss(tvalleys);
n_cycles = length(tvalleys);
[~,sorted_valleys]= sort(valleys,'ascend');

% initialize bookeeping 
tdrains = zeros(length(Ss),1);

% initialize output arrays
Ni = zeros(1,n_cycles,'single');
dS = zeros(1,n_cycles,'single');
Sm = zeros(1,n_cycles,'single');

% evaluate one valley at the time, starting from lowest
for vi = 1:length(valleys)
    
    v = sorted_valleys(vi); % valley no. sorted from largest to smallest

    % find "water level" (Smax) of valley
        %search left
        t = tvalleys(v);
        Smax_left = Ss(t);
        while t>=1 && ~tdrains(t) 
            Smax_left = max(Smax_left,Ss(t));
            t = t-1;
        end

        %search right
        t = tvalleys(v);
        Smax_right = Ss(t);
        while t<=length(Ss) && ~tdrains(t) 
            Smax_right = max(Smax_right,Ss(t));
            t = t+1;
        end

    % get min/max stress value for current ranbge
    Smax = min(Smax_left,Smax_right);
    Smin = valleys(v);
    
    % extract ranges
    Ni(vi) = 1;
    dS(vi) =  Smax - Smin;
    Sm(vi) = (Smax + Smin)/2;
    
    % mark time-location of current valley as drained
    tdrains(tvalleys(v)) = 1;
    
end

% assemble rf array
% rf(1,1) = range(S);
% rf(2,1) = mean(S);
% rf(3,1) = range(S);
% rf(4,1) = 1;
% rf(5,1) = range(S);
rf = [dS; Sm; dS; Ni; dS];



function [peaks,idx] = findpeaks(S)
% extract list of peaks

n_steps = size(S,1);
peaks = zeros(n_steps,1,'single');
idx   = zeros(n_steps,1,'single');
j=0;

for i = 2:length(S)-1
    if (S(i)>S(i-1) && S(i)>S(i+1)) 
        j = j+1;
        peaks(j) = S(i);
        idx(j)   = i;
    end
end
   
% remove unused entries
peaks(j+1:end) = [];
idx(j+1:end) = [];

% coder -build reservoir_counting.prj