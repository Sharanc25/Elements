function wire_frame = edge_detection(face_table,node_table,face_norms,atol) %#codegen
% Finds the hard edges in the mesh and construct wire frame model

n_faces = size(face_table,1);
n_edges = n_faces*4;

edge_table = zeros(n_edges,5,'uint32');
e = 1;

% build edge table:
% edge_table(v1 v2 f1 f2 h)
% v1,v2 = vertices defining edge
% f1,f2 = adjacent faces
% h     = hard edge 1/0
for f = 1:n_faces

    cur_face = uint32(face_table(f,1:4)); % indices of nodes (vertices)
    n_verts = length(unique(cur_face));

    for v = 1:n_verts

        % edge vertices
        v1 = cur_face(v);
        if v < n_verts
            v2 = cur_face(v+1);
        else
            v2 = cur_face(1);
        end

        edge_table(e,1:3) = [min(v1,v2) max(v1,v2) f];
        e = e + 1;

    end

end

% clear unused entries
edge_table(edge_table(:,1)==0,:) = [];




% remove duplicated edges (all edges are now registered twice)
edge_table = sortrows(edge_table);
n_edges = size(edge_table,1); % approx 2x no. edges, because of duplicates

for i = 1:n_edges-1

    % vertices defining edge
    e_cur  = edge_table(i,1:3);
    e_next = edge_table(i+1,1:3);

    % if the vertices defining two subsequent edges in the sorted list,
    % eliminate one and add the associated face number to the other.
    if e_cur(1)==e_next(1) && e_cur(2) == e_next(2)
        edge_table(i,4) = e_next(3);
        edge_table(i+1,1:3) = [0 0 0];
    end

end

% clear unused entries
edge_table(edge_table(:,1)==0,:) = [];


n_edges = size(edge_table,1);
hard_edges = zeros(n_edges,2,'uint32');
e = 1;

% check for hard edges
for i = 1:n_edges

    % check angle between opposing face normals
    n1 = face_norms(edge_table(i,3),:)';

    opposing_face = edge_table(i,4);

    if opposing_face 
        n2 = face_norms(opposing_face,:)';  

        v_cross = single(n1'*n2);
        if v_cross >1
            v_cross = single(1);
        elseif v_cross<-1
            v_cross = single(-1);
        end

        a = abs(real(acos(v_cross)));
    else % if no opposing face is found -> hard edge
        a = single(atol+1);
    end

    if a > atol
        hard_edges(e,:) = edge_table(i,1:2);
        e = e + 1;
    end

end
hard_edges(hard_edges(:,1)==0,:) = [];

% build wireframe model
n_edges = size(hard_edges,1);
wire_frame = zeros(3,3*n_edges,'single');
for e = 1:n_edges
    v1 = hard_edges(e,1);
    v2 = hard_edges(e,2);
    c1 = node_table(v1,2:4)';
    c2 = node_table(v2,2:4)';
    wire_frame(1:3, (e*3-2):(e*3) ) = [c1 c2 [NaN NaN NaN]'];
end

% coder -build edge_detection.prj