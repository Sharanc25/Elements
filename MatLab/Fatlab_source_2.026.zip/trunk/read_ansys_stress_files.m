function output_table = read_ansys_stress_files(filename,report)
% Reads ANSYS PRNSOL,S export files.
tic

% open and scan entire file
fid = fopen(filename);
if report
    fprintf('\t%s ... ',filename);
end
file = textscan(fid,'%s','delimiter',sprintf('\n'),'whitespace','');
file = file{1};

% initialize arrays
lline = cellfun(@length,file);
file(lline~=81) = [];
file = cell2mat(file);

stress_table = file(:,10:end);
output_table = zeros(size(file,1),7,'single');

% convert to numeric
for i=1:7
    if i==1
        table = file(:,1:8)';
        format = '%8d';
    else
        j=i-1;
        pos = (j*12-11):(j*12);
        table = stress_table(:,pos)';
        format = '%12f';
    end
    
    output_table(:,i) = sscanf(table,format);
    
end

fclose(fid);
if report
    fprintf('%.2fs\n',toc)
end



