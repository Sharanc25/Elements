function Sf = calc_fatigue_stress(S,stress_mode,multi) %#codegen
% Generate fatigue effective stress-time series, Sf, from stress tensor time series S.

[n_step,~] = size(S);

    switch stress_mode
        case 'Sxx  '
            Sf = S(:,1);
        case 'Syy  '
            Sf = S(:,2);
        case 'Szz  '
            Sf = S(:,3);
        case 'Txy  '
            Sf = S(:,4);
        case 'Txz  '
            Sf = S(:,5);
        case 'Tyz  '
            Sf = S(:,6);
        case 'Svm  '
            Sf = von_mises(S,false);
        case 'Ssvm '
            Sf = von_mises(S,true);
        case 'P1   '
            Sf = principal_stress(S,'P1');
        case 'P2   '
            Sf = principal_stress(S,'P2');
        case 'P3   '
            Sf = principal_stress(S,'P3');
        case 'Pnmax'
            Sf = principal_stress(S,'Pnummax');
        case 'Tmax '
            Sf = principal_stress(S,'Tmax');
        case 'CP   '
            Sf = stress_on_plane(S,multi);
        case 'Pall '
            Sf = principal_stress(S,'Pall');
        case 'Pdir '
            Sf = principal_stress(S,'Pdir');
        case 'Pmdir'
            Sf = principal_stress(S,'Pmdir');
        case 'Pi   '
            Sf = principal_stress(S,'Pi');
        case 'Sall '
            Sf = S(:,1:3);
        case 'Tall '
            Sf = S(:,4:6);
        case 'Shyd '
            Sf = principal_stress(S,'hyd');
        otherwise 
            Sf = zeros(n_step,1,'single');
    end
  
    
end

function Sp = stress_on_plane(S,multi)
    
    n_steps = size(S,1);
    [theta,phi] = search_plane_angles(multi.n_planes);
    n_planes = multi.n_planes(1)*multi.n_planes(2);
    np = 0;
    
    Sn = coder.nullcopy(zeros(n_steps,1,'single'));
    Tu = coder.nullcopy(zeros(n_steps,1,'single'));
    Tv = coder.nullcopy(zeros(n_steps,1,'single'));
    
    % differentiate between normal and shear stress based criteria
    if strcmp(multi.criterion,'Normal stress  ')
        calc_shear = false;
        Sp = coder.nullcopy(zeros(n_steps,n_planes,'single'));
    else
        calc_shear = true;
        if strcmp(multi.criterion,'Modified shear ')
            Sp = coder.nullcopy(zeros(n_steps,n_planes,'single'));
        else
            Sp = coder.nullcopy(zeros(n_steps,n_planes*3,'single'));
        end
    end
    
    % stress components: SX, SY, SZ, SXY, SYZ, SXZ
    sx  = S(:,1);
    sy  = S(:,2);
    sz  = S(:,3);
    txy = S(:,4);
    tyz = S(:,5);
    txz = S(:,6);
            
    % construct local node frame
    n_s = multi.node_normal; % surface normal (local z')
    x   = multi.node_axis;   % local x'
    y   = cross(n_s,x);      % local y'
    Ai  = [x y n_s];         % intial frame
    
    for t = 1:length(theta)
        
        % rotate local frame by theta around local z' (surface normal)
        At = RotA(Ai,theta(t),[0 0 1]'); 
        
        for p = 1:length(phi)

            A = RotA(At,phi(p),[0 1 0]'); % then rotate phi about intermediate y' (to get inclination)

            % normal stress on search plane (Socie & Marquis, Multiaxial Fatigue, 2000)
            Sn = sx*A(1,1)^2 + sy*A(2,1)^2 + sz*A(3,1)^2 + ...
                 2*( txy*A(1,1)*A(2,1) + tyz*A(2,1)*A(3,1) + txz*A(1,1)*A(3,1) );
                
            % shear stresses on search plane
            I1 = Sn;
            if calc_shear
                Tu = sx*A(1,1)*A(1,2) + sy*A(2,1)*A(2,2) + sz*A(3,1)*A(3,2) + ...
                     txy*(A(1,1)*A(2,2) + A(2,1)*A(1,2)) + ...
                     tyz*(A(2,1)*A(3,2) + A(3,1)*A(2,2)) + ...
                     txz*(A(3,1)*A(1,2) + A(1,1)*A(3,2));

                Tv = sx*A(1,1)*A(1,3) + sy*A(2,1)*A(2,3) + sz*A(3,1)*A(3,3) + ...
                     txy*(A(1,1)*A(2,3) + A(2,1)*A(1,3)) + ...
                     tyz*(A(2,1)*A(3,3) + A(3,1)*A(2,3)) + ...
                     txz*(A(3,1)*A(1,3) + A(1,1)*A(3,3));
                I1 = sx + sy + sz;
            end
            
            % plane no.
            np = np + 1;
            
            % return stress on plane
            switch multi.criterion
                case 'Normal stress  '
                    Sp(:,np) = Sn; % just use the normal stress only
                case 'Modified shear ' % e.g. IIW (Gough-Pollard ellipse)
                    Sp(:,np) = sign(I1).*sqrt(Sn.^2 + multi.k(1)^2*Tu.^2);
                otherwise % shear stress based
                    % assemble sets of [Sn,Tu,Tv] for each plane
                    Sp(:,3*np-2:3*np) = [Sn Tu Tv];
            end

        end 
    end
end

function Svm = von_mises(S,signed)

    % stress components ANSYS: SX, SY, SZ, SXY, SYZ, SXZ  
    sx  = S(:,1);
    sy  = S(:,2);
    sz  = S(:,3);
    txy = S(:,4);
    tyz = S(:,5);
    txz = S(:,6);   
    
    % von Mises stress
    Svm = sqrt(0.5*( (sx-sy).^2 + (sy-sz).^2 + (sz-sx).^2 ...
                        + 6*(txy.^2 + txz.^2 + tyz.^2)) );
                    
    if signed
        I1 = sx + sy + sz;
        Svm = sign(I1) .* Svm;
    end
                    
end

function Sp = principal_stress(S,type)

    n_step = size(S,1);
    
    P  = zeros(n_step,3,'single'); % principal stresses
    iP = zeros(n_step,3,'single'); % index of P1,2,3 in P
    psi = zeros(n_step,3,'single'); % principal frame
    
    for t = 1:n_step

        % stress-tensor:
        St = [S(t,1) S(t,4) S(t,6); 
              S(t,4) S(t,2) S(t,5);
              S(t,6) S(t,5) S(t,3)];
        % eigen values = principal stresses
        % eigen vectors = principal frame direction cosines

        if any(any(St)) % not all zeros
            [A,E] = eig(St);
            Pt = real([E(1,1); E(2,2); E(3,3)]); 
            psi(t,:) = TrMatrixToBryant(A);
            [P(t,:), iP(t,:)] = sort(Pt,'descend');
        else
            P(t,:)   = [0 0 0];
            iP(t,:)  = [1 2 3];
            psi(t,:) = [0 0 0];
        end
        
    end
    
    switch type
        case 'P1'
            Sp = P(:,1);
        case 'P2'
            Sp = P(:,2);
        case 'P3'
            Sp = P(:,3);
        case 'Pall'
            Sp = P(:,1:3);
        case 'Tmax'
            Sp = ( P(:,1) - P(:,3) )/2;
        case 'hyd'
            Sp = sum(P(:,:),2)/3;
        case 'Pnummax'
            Sp = zeros(n_step,1,'single');
            for t = 1:n_step
                p = P(t,:);
                [pmax,i] = max(abs(p));
                Sp(t) = sign(P(t,i))*pmax;
            end
        case 'Pmdir'
            Sp = zeros(n_step,3,'single');
            for t = 1:n_step

                sy  = S(t,2);
                sz  = S(t,3);
                txy = S(t,4);
                tyz = S(t,5);
                txz = S(t,6);

                p = P(t,:);
                [~,i] = max(abs(p));
                
                a = (sy - p(i))*(sz-p(i)) - tyz^2;
                b = -(txy*(sz-p(i)) - txz*tyz);
                c = txy*tyz - txz*(sy - p(i));
                k = 1/sqrt(a^2 + b^2 + c^2);
                
                Sp(t,:) = real([a*k; b*k; c*k])';
            end
        case 'Pdir' % principal frame 
            Sp = psi;
        case 'Pi' % index of P1,2,3
            Sp = iP;
    end
    
end

%coder -build calc_fatigue_stress.prj