function [esize, face_table] = calc_elem_size(node_table,face_table)
% estimate element side length

    n_faces = size(face_table,1);
    face_table_out = [face_table zeros(n_faces,1,'single')];
    
    for f = 1:n_faces
        
        cur_face = face_table(f,1:4);
        
        pi = node_table(cur_face(1),2:4);
        pj = node_table(cur_face(2),2:4);
        pk = node_table(cur_face(3),2:4);
        
        face_table_out(f,9) = (norm(pj-pi) + norm(pj-pk))/2;
        
    end
    
    esize = mean(face_table_out(:,9));

end