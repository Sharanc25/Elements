function rf_all = rfc_all_lc(node_no,FE,LC,options,stress_mode)

n_lc   = length(LC);
rf_all = [];
    
for lc = 1:n_lc

    % calculate fatigue relevant stress-time series
    S = calc_stress(node_no,FE,LC(lc).L,stress_mode,options.multi);

    % rain flow counting
    rf = cycle_counter(S,LC(lc).n,options);
    
    % accumulate
    rf_all = [rf_all rf];
    
end