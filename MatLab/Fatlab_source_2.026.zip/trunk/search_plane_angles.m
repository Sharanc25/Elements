function [theta,phi] = search_plane_angles(n_planes)
% return vectors containing the angle-pairs defining a set of search
% planes for the critical plane method.

    n_theta = n_planes(1);
    n_phi   = n_planes(2);

    dt    = pi/n_theta;
    theta = 0:dt:(pi-dt);
    
    if n_phi == 1
        phi = 0;
    elseif n_phi == 2
        phi = [0 pi/4];
    else % n_phi >2
        dp  = (pi/2)/(n_phi-1);
        phi = 0:dp:(pi/2);
    end
end