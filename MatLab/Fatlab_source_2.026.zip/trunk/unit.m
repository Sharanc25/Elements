function u = unit(v)
% Returns the unit vector of input v

u = v/norm(v);
