function rf_eq = equivalent_uniaxial(rf,options,SN,Sinv)
% Calculate an equivalent uniaxial stress range using the selected multiaxial criteria

    Ta   = rf(1,1)/2; % shear stress amplitude
    Sa   = rf(2,1);   % normal stress amplitude
    Sm   = rf(3,1);   % mean normal stress
    ni   = rf(4,1);   % no cycles
    Smax = rf(5,1);   % max normal stres
    
    M  = SN.M;         % mean stress sensitivity (dS_R=-1/dS_R=0-1)
    k1 = options.multi.k(1);
    k2 = options.multi.k(2);
    
    switch options.multi.criterion
        case 'Findley        '
            dTn = 2*Ta;
            dSeq = (dTn + 2*k1*Smax)/(0.5*(k1+sqrt(1+k1^2)));
        case 'IIW equivalent '
            dS = Sa*2;
            dT = Ta*2;
            dSeq = 1/sqrt(k2) * sqrt(dS^2 + k1*dT^2);
%         case 'Modified shear '
%             dS = Sa*2;
%             dT = Ta*2;
%             dSeq = (dS^2 + k*dT^2)^(1/2);
%         case 'Matake         '
%             dSeq = 2*(Ta + k*Sinv.hyd_max);
%              
%         case 'Dang Van       '
%             a = k;
%             b = 3-1.5*k;
%             dSeq = 2*(a*Ta + b*Sinv.hyd_max);
%         
%         case 'Sines          '
%             a = k;
%             b = 6*(M+1) - sqrt(3)*k;
%             dSeq = 2*(a*Sinv.sqrtJ2a + b*Sinv.hyd_mean);
%                 
%         case 'Papuga PCr     '            
%             a = k^2/2 + sqrt(k^4-k^2)/2;
%             b = dSatN(ni,SN);
%             d = (M+1)/k;
%             dSeq = sqrt(a*Ta^2 + b*(Sa + d*Sm));
%         
%         case 'EC3 equivalent '
%             dS = Sa*2;
%             dT = Ta*2;
%             dSeq = (dS^3 + k*dT^5)^(1/3);
            
    end

    % return equivalent stress range
    rf_eq(1,1) = dSeq;
    rf_eq(2,1) = 0;
    rf_eq(3,1) = 0;
    rf_eq(4,1) = ni;
    rf_eq(5,1) = 0;

end
