function stress = stress_vector_plot(node_list,load_table,ULC_table,node_stress,Li,esize,node_coords,scale_vec,options)

    n_nodes = length(node_list);
    n_steps = size(Li.L,1);
    max_mag = 0;
    
    node(n_nodes).mag   = zeros(n_steps,3,'single');
    node(n_nodes).dir   = zeros(n_steps,3,'single');
    node(n_nodes).pmdir = zeros(n_steps,3,'single');
    node(n_nodes).pi    = zeros(n_steps,3,'single');
    
    structure = struct('mag',zeros(3,n_nodes,'single'), ...
                       'p1',zeros(3,3*n_nodes,'single'),...
                       'p2',zeros(3,3*n_nodes,'single'),...
                       'p3',zeros(3,3*n_nodes,'single'),...
                       'pm',zeros(3,3*n_nodes,'single'));
	stress = repmat(structure,1,n_steps);
    
    step_size = floor(n_nodes/100);
    if step_size<1; step_size = 1; end
    hwb = awaitbar(0,'Calculating principal stresses...');
    
    
    
    % calculate principal stresses and directions
    for n = 1:n_nodes
        
        ni = node_list(n);
        
        % calculate stress tensor over time [n_time_steps x 6]
        S = calc_stress_nonlinear_mex(load_table,ULC_table,node_stress(ni).table,Li.L);

        % from this, pick or calculate a fatigue effective stress-time series [n_time_steps x 1/3]
        node(n).mag   = calc_fatigue_stress_mex(S,'Pall ',options.multi);
        node(n).dir   = calc_fatigue_stress_mex(S,'Pdir ',options.multi);
        node(n).pmdir = calc_fatigue_stress_mex(S,'Pmdir',options.multi);
        node(n).pi    = calc_fatigue_stress_mex(S,'Pi   ',options.multi);
        
        cur_max_mag = max(max(abs(node(n).mag)));
        
        if cur_max_mag > max_mag;
            max_mag = cur_max_mag;
        end
        
        % update waitbar
        if mod(n,step_size)==0
            abort = awaitbar(n/n_nodes);
            if abort; 
                return; 
            end	
        end

    end

    
    %delete waitbar
    delete(hwb);
    
    
    
    step_size = floor(n_steps/100);
    if step_size<1; step_size = 1; end
    hwb = awaitbar(0,'Generating vector plot...');
    
    for t = 1:n_steps
        
        for n = 1:n_nodes
        
            mag_j   = node(n).mag(t,:)';
            dir_j   = node(n).dir(t,:)';
            pmdir_j = node(n).pmdir(t,:)';
            pi      = node(n).pi(t,:)';

            if scale_vec
                scale = 0.5*esize * (mag_j/max_mag);
                pmscale = max(abs(scale));
            else 
                scale = 0.5*[1 1 1]'*esize;
                pmscale = scale(1);
            end

            A = BryantTrMat(dir_j');
            p = node_coords(n,:)';

            p1 = A(:,pi(1))*scale(1);
            p2 = A(:,pi(2))*scale(2);
            p3 = A(:,pi(3))*scale(3);
            
            stress(t).mag = mag_j;
            stress(t).p1(1:3, (n*3-2):(n*3) ) = [p-p1 p+p1 [NaN NaN NaN]'];
            stress(t).p2(1:3, (n*3-2):(n*3) ) = [p-p2 p+p2 [NaN NaN NaN]'];
            stress(t).p3(1:3, (n*3-2):(n*3) ) = [p-p3 p+p3 [NaN NaN NaN]'];

            pm = pmscale * pmdir_j;
            stress(t).pm(1:3, (n*3-2):(n*3) ) = [p-pm p+pm [NaN NaN NaN]'];
        end
       
          % update waitbar
        if mod(t,step_size)==0
            abort = awaitbar(t/n_steps);
            if abort; 
                return; 
            end	
        end
        
    end
    
    %delete waitbar
    delete(hwb);
    
end
