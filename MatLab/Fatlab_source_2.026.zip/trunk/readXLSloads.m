function loads = readXLSloads(file)
% Read FATLAB style loads from MS Excel file.

[~,sheets] = xlsfinfo(file);
n_lcs = length(sheets);

hwb = waitbar(0,'Reading loads file.');

for i = 1:n_lcs
    
    % read xls sheets 1 by 1
    [num,txt] = xlsread(file,i);
    [n_rows,n_cols] = size(num);
    
    % get number of loads
    j=2;
    n_loads = 0;
	while(j<=n_cols && ~isnan(num(4,j)))
        n_loads = n_loads + 1;
        j = j + 1;
    end
    
    % get number of time steps
    j=4;
    n_steps = 0;
	while(~isnan(num(j,1)) && j<n_rows)
        n_steps = n_steps + 1;
        j = j + 1;
    end
    
    % extract info
    loads(i).desc   = sheets{i};
    loads(i).n      = num(1,2);
    loads(i).Lcomps = txt(2,2:(1+n_loads));
    loads(i).Lunits = txt(3,2:(1+n_loads));
    loads(i).t      = single(num(4:(4+n_steps),1));
    loads(i).ti     = single(num(4:(4+n_steps),1));
    loads(i).L      = single(num(4:(4+n_steps),2:(1+n_loads)));
    loads(i).Li     = single(num(4:(4+n_steps),2:(1+n_loads))); % copy (un-modified loads)
    loads(i).scale  = ones(1,n_loads);
    loads(i).offset = zeros(1,n_loads);
    
    waitbar(i/n_lcs,hwb);
    
end

loads(1).plot = logical(1:length(loads(1).Lcomps));
 
close(hwb);