function dSR = dSatN(n,SN)

    % no mean stress dependency
    %dsR2 = mean_stress(Smi,SN);

    % get SN curve data
    dsR2   = SN.ds2;
    NR2    = SN.N2;
    m1     = SN.m1;
    m2     = SN.m2;
    dSmin  = SN.minS;

    % fatigue capacity (corrected for mean stress)
    if n<=NR2
        C1  = NR2*dsR2^m1; 
        dSR = (C1/n)^(1/m1);
    else
        C2  = NR2*dsR2^m2;
        dSR = (C2/n)^(1/m2);
    end

    if dSR < dSmin
        dSR = dSmin;
    end
    
end