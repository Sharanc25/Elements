function phi = TrMatrixToBryant(A)

    phi = zeros(3,1,'single');
    sTheta2 = real(A(1,3));
    cTheta2 = real(sqrt(1-sTheta2^2));

    cTheta3 = real( A(1,1)/cTheta2);
    sTheta3 = real(-A(1,2)/cTheta2);

    sTheta1 = real(-A(2,3)/cTheta2);
    cTheta1 = real( A(3,3)/cTheta2);

    phi(1) = atan2(sTheta1,cTheta1);
    phi(2) = atan2(sTheta2,cTheta2);
    phi(3) = atan2(sTheta3,cTheta3);

end
