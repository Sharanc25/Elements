function [results,options] = run_analysis(options,model,LC,FE,SN,results)

    global hs
    
    % left, bottom, width, height
    hs.fig = figure('name','Run analysis','NumberTitle','off','units','characters','position', [65 15 135 34],...
                    'color',[0.941176 0.941176 0.941176],'windowstyle','modal','WindowKeyPressFcn',@ok_cancel,'Resize','off'); 
    change_icon(hs.fig,'icon.png');
    center_gui(hs.fig);
    pos   = get(hs.fig,'pos');
    width = pos(3);
    
    setappdata(hs.fig,'results',results);
    setappdata(hs.fig,'options',options);
    setappdata(hs.fig,'model',model);
    setappdata(hs.fig,'LC',LC);
    setappdata(hs.fig,'SN',SN);
    setappdata(hs.fig,'FE',FE);
    
    
    % performance panel
    core_list{1} = 'Single core';
    for i=2:1:12
        core_list{end+1} = [num2str(i) ' cores'];
    end
    
    parallel_allow = 'off';
    if options.toolbox_parallel_computing==1
        parallel_allow = 'on';
    end
    
    b = [1.5 3.5];
    hs.pan1      = uipanel('units','characters','pos',[2 19+7 width-4 7],'title','Performance');
    hs.txt       = uicontrol('Style','text','String','Parallel run:','units','characters','pos',           [2  b(2) 23 1],'parent',hs.pan1,'horizontalalignment','left');    
    hs.cores     = uicontrol('style','popup','string',core_list,'pos',                                     [28 b(2)+0.4 20 1.],'value',options.n_cores,'parent',hs.pan1,'callback',@cb_multicore,'backgroundcolor','w','enable',parallel_allow);
    hs.txt       = uicontrol('Style','text','String','Racetrack filter:','units','characters','pos',       [2  b(1) 23 1],'parent',hs.pan1,'horizontalalignment','left');
    hs.racetrack = uicontrol('Style','edit','string',num2str(options.racetrack),'units','characters','pos',[28 b(1)-0.4 20 1.6],'parent',hs.pan1,'callback',@cb_racetrack,'backgroundcolor','w','horizontalalignment','right');
    
    % scope panel
    hs.bg     = uibuttongroup('Title','Select nodes (scope of analysis)','units','characters','Position',[2 4+7 width-4 14],'SelectionChangeFcn',@cb_scope);
    hs.rall   = uicontrol(hs.bg,'Style','radiobutton','String','All nodes','Position',[2 11 20 1]);
    hs.rvis   = uicontrol(hs.bg,'Style','radiobutton','String','All visible nodes','Position',[2 9 45 1]);
    hs.rfile  = uicontrol(hs.bg,'Style','radiobutton','String','Nodelist from file','Position',[2 7 20 1]);
    hs.rrange = uicontrol(hs.bg,'Style','radiobutton','String','Node range','Position',[2 5 20 1]);
    hs.rsel   = uicontrol(hs.bg,'Style','radiobutton','String','Selected (single) node','Position',[2 3 30 1]);
    hs.rres   = uicontrol(hs.bg,'Style','radiobutton','String','Nodes from previous result set with D >','Position',[2 1 45 1],'enable','off');

    hs.editf  = uicontrol('Style','edit','String','','units','characters','pos',               [25   6.8 80 1.5],'parent',hs.bg,'horizontalalignment','left','backgroundcolor','w','enable','off');
    hs.editr  = uicontrol('Style','edit','String','','units','characters','pos',               [25   4.8 80 1.5],'parent',hs.bg,'horizontalalignment','left','backgroundcolor','w','enable','off','callback',@cb_run);
    hs.editd  = uicontrol('Style','edit','String','0.9','units','characters','pos',            [47   0.8 8 1.5],'parent',hs.bg,'horizontalalignment','left','backgroundcolor','w','enable','off','callback',@cb_run);
    hs.browsef= uicontrol('Style','pushbutton','string','Browse...','units','characters','pos',[108  6.6 16 1.75],'callback',@cb_browse,'parent',hs.bg,'enable','off');
    
    switch options.node_scope
        case 1 % all nodes
        case 2 % node list file
            set(hs.bg,'SelectedObject',hs.rfile);
            set(hs.editf,'string',options.node_scope_str,'enable','on');
        case 3 % node range
            set(hs.bg,'SelectedObject',hs.rrange);
            set(hs.editr,'string',options.node_scope_str,'enable','on');
        case 4 % selected single node
            set(hs.bg,'SelectedObject',hs.rsel);
        case 5 % nodes from results
            set(hs.bg,'SelectedObject',hs.rres);
            set(hs.editd,'string',options.node_scope_str,'enable','on');
        case 6 % all visible nodes
            set(hs.bg,'SelectedObject',hs.rvis);
        otherwise
            error('error in setup_model.m');
    end
    
    if ~isempty(results)
        set(hs.rres,'enable','on');
    end
    
    
    % damage accumulation panel
    hs.accu   = uibuttongroup('Title','Damage accumulation','units','characters','Position',[2 4 width-4 6],'SelectionChangeFcn',@cb_accu);
    hs.anew   = uicontrol(hs.accu,'Style','radiobutton','String','New analysis (start from zero damage)','Position',[2 3 55 1]);
    hs.acon   = uicontrol(hs.accu,'Style','radiobutton','String','Continue analysis (add damage to existing results)','Position',[2 1 55 1],'Enable','off');

    if ~isempty(results)
        set(hs.acon,'enable','on');
    end
    
    switch options.accumulation
        case 1
            set(hs.accu,'SelectedObject',hs.anew');
        case 2
            set(hs.accu,'SelectedObject',hs.acon');
    end
    
    % run/cancel
    hs.cancel = uicontrol('Style','pushbutton','string','Cancel','units','characters','pos',[116 1 16 1.75],'callback',@cb_cancel);
    hs.run    = uicontrol('Style','pushbutton','string','Run','units','characters','pos',[98 1 16 1.75],'callback',@cb_run);
    
    set(gcf,'Visible','on');
    drawnow;
    hs.run_pressed = false;
    uicontrol(hs.run)
    uiwait(hs.fig);
    
    if hs.run_pressed  
        options = getappdata(hs.fig,'options');
        results = getappdata(hs.fig,'results');    
        close(hs.fig);
    end
        
end

function ok_cancel(~,event)

    if strcmp(event.Key,'escape')
        cb_cancel();
    elseif strcmp(event.Key,'return')
        cb_run();
    end

end

function cb_multicore(~,~)

    global hs
    
    options = getappdata(gcf,'options');
    set(hs.fig,'Pointer','watch'); drawnow;
    
    % get number of cores chosen by user
    n_cores = get(hs.cores,'value');
        
    if n_cores > 1
        
        % setup parallel workers pool
        pool = gcp('nocreate');
        if isempty(pool) 
            parpool(n_cores);
        elseif n_cores ~= pool.NumWorkers
            delete(pool);
            parpool(n_cores);
        end

        % add java elements for parforprogmon
        pctRunOnAll javaaddpath java
        
    else
        delete(gcp);
    end
    
    options.n_cores = n_cores;
    setappdata(hs.fig,'options',options);
    set(hs.fig,'Pointer','arrow'); drawnow;
    
end


function cb_racetrack(~,~)

    global hs
    options = getappdata(hs.fig,'options');

    options.racetrack = str2num(get(hs.racetrack,'string'));
    
    if options.racetrack>0.1
        warndlg('Racetrack filtering more than 0.1*max_range is not recommended.');
    end
    
    setappdata(hs.fig,'options',options);
    
end


function cb_accu(~,~)
    
    global hs
    options = getappdata(hs.fig,'options');
        
    switch get(hs.accu,'SelectedObject')
        case hs.anew
            options.accumulation = 1;
        case hs.acon
            options.accumulation = 2;
    end
    
    setappdata(hs.fig,'options',options);
    
end

function cb_scope(~,~)
    
    global hs
    options = getappdata(hs.fig,'options');
    
    set(hs.editf,'enable','off');
    set(hs.editr,'enable','off');
    set(hs.editd,'enable','off');
    set(hs.browsef,'enable','off');
    
    switch get(hs.bg,'SelectedObject')
        case hs.rall
            options.node_scope = 1;
        case hs.rfile
            set(hs.editf,'enable','on');
            set(hs.browsef,'enable','on');
            options.node_scope = 2;
        case hs.rrange
            set(hs.editr,'enable','on');
            options.node_scope = 3;
        case hs.rsel
            options.node_scope = 4;
        case hs.rres
            set(hs.editd,'enable','on');
            options.node_scope = 5;
        case hs.rvis
            options.node_scope = 6;
    end
    
    setappdata(hs.fig,'options',options);
    
end

function cb_browse(~,~)
    
    global hs
	
    options = getappdata(hs.fig,'options');
    
    [filename,filepath,~] = uigetfile('*.txt','Please select node list file',[options.files.work_folder '\nodelist.txt']);
    set(hs.editf,'string',[filepath filename]);
    
end

function cb_cancel(~,~)

    global hs
    uiresume(hs.fig);
    close(hs.fig);

end


function cb_run(~,~)

    global hs
    
    
    options = getappdata(hs.fig,'options');
    model   = getappdata(hs.fig,'model');
    results = getappdata(hs.fig,'results');
    LC      = getappdata(hs.fig,'LC');
    FE      = getappdata(hs.fig,'FE');   
    SN      = getappdata(hs.fig,'SN');
    
    if isempty(model)
        errordlg('No model loaded.','Error')
        return;
    elseif isempty(FE(1).ULC)
        errordlg('No FE stress input found.','Error')
        return;
    elseif isempty(LC)
        errordlg('No loads found.','Error')
        return;
    end
        
    % get nodelist
    switch get(hs.bg,'SelectedObject')
        case hs.rall %default
            node_scope_str = 'all';
            all_nodes = options.all_nodes;
            n_nodes   = length(all_nodes);
            options.nodelist  = all_nodes;
            options.nodelisti = (1:n_nodes)';
            
        case hs.rvis
            node_scope_str = 'visible';
            
            vis_nodesi = model.surf.vis_nodesi;
            vis_nodes  = model.surf.node_table(vis_nodesi,1);
            
            options.nodelist  = vis_nodes;
            options.nodelisti = vis_nodesi;
            
            n_nodes = length(vis_nodesi);
            
        case hs.rfile
            try
                node_scope_str    = get(hs.editf,'string');
                options.nodelist  = read_nodelist(node_scope_str,'ansys');
                n_nodes = length(options.nodelist);
                options.nodelisti = zeros(n_nodes,1);
                
                for i=1:n_nodes
                    node = options.nodelist(i);
                    options.nodelisti(i) = model.surf.mapping.node2ni(node);
                end
                
            catch
                error('Error reading node list file.');
            end
            
        case hs.rrange
            node_scope_str = get(hs.editr,'string');
            if ~isempty(node_scope_str)
                range_nodes = eval(node_scope_str);
            else
                error('No node range specified.');
            end
            
            if size(range_nodes,2)>1
                range_nodes = range_nodes';
            end
            
            n_nodes = length(range_nodes);
            options.nodelist  = range_nodes;
            options.nodelisti = zeros(n_nodes,1);
            
            for i=1:n_nodes
                node = range_nodes(i);
                try
                    options.nodelisti(i) = model.surf.mapping.node2ni(node);
                catch
                    error('Node number not recognized.');
                end
            end
            
        case hs.rsel
            node_scope_str = 'selected';
            n_nodes   = 1;
            try 
                options.nodelist  = model.selected_node.node_name;
                options.nodelisti = model.selected_node.node_index;
            catch 
                options.nodelist  = [];
                options.nodelisti = [];
            end
            
        case hs.rres
            node_scope_str = get(hs.editd,'string');
            Dlim = str2num(node_scope_str);
            
            selected_node_logical = results.Dtot>Dlim;
            selected_node_names   = model.surf.node_table(selected_node_logical,1);
            selected_node_indices = model.surf.mapping.node2ni(selected_node_names,1);
            
            options.nodelist  = selected_node_names;
            options.nodelisti = selected_node_indices;
            n_nodes = length(options.nodelist);
            
    end
   
    options.node_scope_str = node_scope_str;
    options.n_nodes        = n_nodes;
    setappdata(hs.fig,'options',options);
    fprintf(1,'Running fatigue analysis\n'); tic
    
    % initialize parallel computing toolbox
    %cb_multicore();
    javaaddpath java
            
    % do fatigue calculations
    %profile on
    set(hs.fig,'Pointer','watch'); drawnow;
    results = fatigue_calc(FE,LC,SN,options,model,results,options.nodelisti);
    setappdata(hs.fig,'results',results);
    set(hs.fig,'Pointer','arrow');
    %profile off
    %profile viewer

    fprintf(1,'Analysis done. %.02fs\n',toc);
    
    hs.run_pressed = true;
    uiresume(hs.fig);
    
end
