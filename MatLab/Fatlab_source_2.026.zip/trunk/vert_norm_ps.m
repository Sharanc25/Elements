function [normals,planes] = vert_norm_ps(FE,n_planes)

n_nodes = size(FE{1},1);
normals = zeros(n_nodes,3);
planes  = zeros(n_nodes,3*n_planes);

% calculate node (surface) normals
for i = 1:n_nodes

    % use first load in positive direction for orientation
    s = FE{1}(i,:,1);

    % stress tensor
    S = [s(1) s(4) s(5); 
         s(4) s(2) s(6);
         s(5) s(6) s(3)];

    % principal stresses
    p = eig(S);
    p = sort(p,'descend');

    % smalles principal stress gives direction of surface normal
    [~,p_min]= min(abs(p));

    % associated direction cosine
    a = (s(2) - p(p_min))*(s(3)-p(p_min)) - s(6)^2;
    b = -(s(4)*(s(3)-p(p_min)) - s(5)*s(6));
    c = s(4)*s(6) - s(5)*(s(2) - p(p_min));
    k = 1/sqrt(a^2 + b^2 + c^2);

    n = real([a*k; b*k; c*k]);
    normals(i,:) = n;
    
    % P1 gives 1st plane normal
    [~,p_max]= max(p);
    a = (s(2) - p(p_max))*(s(3)-p(p_max)) - s(6)^2;
    b = -(s(4)*(s(3)-p(p_max)) - s(5)*s(6));
    c = s(4)*s(6) - s(5)*(s(2) - p(p_max));
    k = 1/sqrt(a^2 + b^2 + c^2);
    
    x = real([a*k; b*k; c*k]);
    planes(i,:) = rotate_planes(n,x,n_planes);
    
end
