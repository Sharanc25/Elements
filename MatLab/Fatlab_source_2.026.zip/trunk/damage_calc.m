function D = damage_calc(rf,SN)%#codegen
% Palgren-Miner damage calculation
D = 0;

% get SN curve data
NR2    = SN.N2;
m1     = SN.m1;
m2     = SN.m2;
dSmin  = SN.minS;
dSmax  = SN.maxS;

% get stress range, mean stress and cycles
dS = rf(1,:);
Sm = rf(2,:);
n  = rf(4,:);

% damage accumulation
for i = 1:length(dS)

    dSi = dS(i);
    Smi = Sm(i);
    ni  = n(i);
    
    % mean stress dependency
    dsR2 = mean_stress(Smi,SN);
    
    % fatigue capacity (corrected for mean stress)
    C1  = NR2*dsR2^m1; 
    C2  = NR2*dsR2^m2;
            
    % accumulate damage
    if dSi >= dSmax
        fprintf(2,'Warning: max cut-off exceeded for node!\n');
        Ni = C1/dSi^m1;
        Di = max(1,ni/Ni);
        
    elseif dSi >= dsR2
        Ni = C1/dSi^m1;
        Di = ni/Ni;
        
    elseif dSi >= dSmin
        Ni = C2/dSi^m2;
        Di = ni/Ni;
        
    else % dsi < dSmin
        Di = 0; %Ni = inf;
    end

    D = D + Di;
   
end
