function c = calc_centroid(face_table,node_table)

    n_faces = size(face_table,1);
    c   = zeros(n_faces,3,'single');
    
    % calculate centroid for all faces
    for f = 1:n_faces
        
        cur_face = unique(face_table(f,1:4));
        n_nodes = length(cur_face);
        
        for no = 1:n_nodes
            p = node_table(cur_face(no),2:4);
            c(f,:) = c(f,:) + p;
        end
        
        c(f,:) = c(f,:)/n_nodes;
    end
    
end