function model = read_mesh(filename,format,edge_detection_limit)
% Read ANSYS/Simulation FE model (elements + corner-nodes only)
%
% Inputs:
%   filename (string) -> [path\] filename for input file.
%   format (string)   -> input file format, 'ANSYS' or 'SIMULATION'.
% 
% Supported element types:
%   TETRA10 : 3D 10-node tetrahedral solid (ANSYS legacy/Simulation)
%   SOLID187: 3D 10-node tetrahedral solid (ANSYS)
%   SOLID186: 3D 20-node hexahedral solid (ANSYS)
%   PLANE42, PLANE82, PLANE182, PLANE183: 2D 4/8-node quad/triangle (ANSYS)
%   SHELL181, SHELL281, SHELL63:          3D 4/8-node shell (ANSYS)
%
% outputs:
% model.filename = path + filename of the model file
% model.format   = exporting FE software format: 'ANSYS' or 'Simulation'
% model.surf     = reduced model containing surface nodes/elements only, excl. midside nodes
%   node_table   = [node_number, x, y, z] single(n_nodes x 4)
%   elem_table   = [elem_number, type_no, mat_no, node1, ..., node8, com_x, com_y, com_z] single(n_elems x 14)
%   face_table   = [node1, node2, node3, node4, elem_no, centr_x, centr_y, centr_z] single(n_faces x 8)
%   max_dim      = largest range of coordinates in any x,y or z direction
%   model_com    = model center of mass [x,y,z]
%   e_size       = "average" element side length
%   e_types      = list of element type numbers
%   mapping      = maps between names and indices for nodes, elements and faces
%     node2ni    = node name (externally referenced number) -> node index in node_table
%     elem2ei    = element name -> element index in elem_table
%     face2elem  = face index -> element name
%     ni2face    = node index -> face index
%     ni2ei      = node index -> element index
% model.entire   = full model, including all internal + midside nodes
% model.interior = interior/midside node table
% model.dim      = no. dimensions of model 2/3

    tstart=tic;
    hwb = waitbar(0.1,'Reading model file');

    % read text file containing model definition
    [node_table,elem_table,elem_types] = read_file(filename,format);
    node2ni = create_node_map(node_table);
    
    % generate faces
    waitbar(0.4,hwb,'Generating face table');
    face_table = generate_faces_mex(node2ni,elem_table,elem_types);

    % general model data
    model.filename = filename;
    model.format   = format;
    model.tetmap   = [1 2 3 3; 1 2 4 4; 1 3 4 4; 2 3 4 4]; % use 4 vertices for tet faces also.
    model.hexmap   = [1 2 3 4; 1 2 6 5; 2 3 7 6; 3 7 8 4; 1 4 8 5; 5 6 7 8];
    model.quadmap  = [1 2 3 4];

    % return data for entire model
    model.entire.node_table = node_table;
    model.entire.elem_table = elem_table;
    model.entire.elem_types = elem_types;
    model.entire.face_table = face_table;
    model.entire.node2ni    = node2ni;
    
    try
        model.entire.mapping = create_number_maps(node_table,elem_table,face_table);
    catch
        warning('Unable to create mapping structure for interior nodes');
    end
    
    % reduction to surface model
    waitbar(0.6,hwb,'Removing collapsed faces');
    face_table = remove_collapsed_mex(face_table);
    [node_table,elem_table,face_table] = remap(node_table,elem_table,face_table);

	face_table = remove_dup_faces(face_table,node_table,hwb);
    [node_table,elem_table,face_table] = remap(node_table,elem_table,face_table);
      
    waitbar(0.8,hwb,'Calculating model dimensions');
    [elem_table,face_table,max_dim,model_com,esize] = model_dimensions(elem_table,face_table,model.entire);
    
    mapping = create_number_maps(node_table,elem_table,face_table);
    
    % return data for surface model
    model.surf.node_table = node_table;
    model.surf.elem_table = elem_table;
    model.surf.face_table = face_table;
    model.surf.mapping    = mapping;
    model.surf.max_dim    = max_dim;
    model.surf.model_com  = model_com;
    model.surf.esize      = esize;
    model.surf.etypes     = unique(elem_table(:,2));
    
    % index of visible nodes/faces (default=all)
    model.surf.vis_nodesi = (1:length(node_table))';
    model.surf.vis_facesi = (1:length(face_table))';
    
    % subdivide model according to material no. (sub-parts)
    part_nos = unique(model.surf.elem_table(:,3));
    
    for i = 1:length(part_nos)
        model.parts(i).no    = part_nos(i);
        model.parts(i).name  = ['Material #' num2str(part_nos(i))];
        
        part_elem_idx   = (model.surf.elem_table(:,3) == part_nos(i));
        part_elem_names = model.surf.elem_table(part_elem_idx,1);
        
        %[~,model.parts(i).faces] = ismember(part_elem_names,face_table(:,5));    
        [Lia] = ismember(face_table(:,5),part_elem_names);    
        model.parts(i).faces = find(Lia);
        
    end
    
    % no. of dimensions
    if model.entire.elem_types(1)==4 % planar
        model.dim = 2;
    else % spatial
        model.dim = 3;
    end
    
    waitbar(0.85,hwb,'Extracting interior nodes');
    model.interior.node_table = interior_nodes(model);
    
    waitbar(0.87,hwb,'Determining face normals');
    model.surf.face_norms = face_normals_mex(face_table,node_table,elem_table(:,12:14),model.surf.mapping.elem2ei);
    
    waitbar(0.89,hwb,'Determining node normals');
    [model.surf.node_normals, model.surf.node_axis] = node_normals(model);
        
    waitbar(0.92,hwb,'Detecting edges');
    model.surf.wire_frame = edge_detection_mex(face_table,node_table,model.surf.face_norms,deg2rad(edge_detection_limit));
        
    fclose all;
    waitbar(1,hwb,'Done.');
    delete(hwb);
    fprintf('%.2fs\n',toc(tstart))
    

end


%% Sub functions
function [node_table,elem_table,elem_types] = read_file(filename,format)
% read model file exported from ANSYS/Simulation and
% return tables of nodes, elements and element types

    % read text file
    fid = fopen(filename);
    if fid==-1
        error('Can''t find or open file: %s\n',filename); 
    else
        fprintf('Importing FE model: %s ... ',filename);
    end
    file    = textscan(fid,'%s','delimiter',sprintf('\n'),'whitespace','');
    file    = file{1};
    str_array = char(file);
    
    % trim/pad file width
    file_width = 150;
    if size(str_array,2) > file_width
        
        str_array(:,file_width+1:end) = [];
        
    elseif size(str_array,2) < file_width
        
        missing = file_width - size(str_array,2);
        spaces(1:size(str_array,1),1:missing) = ' ';
        str_array = [str_array spaces];
        
    end
    
    switch upper(format)
        case 'SIMULATION' % .GEO file export from Solidworks Simulation
            [node_table,elem_table,elem_types] = read_mesh_simulation_mex(str_array);
                        
        case 'ANSYS' % export format from ETLIST/NLIST/ELIST
            [node_table,elem_table,elem_types] = read_mesh_ansys_mex(str_array);

        case 'CUSTOM'
            [node_table,elem_table,elem_types] = read_mesh_custom(str_array);
        otherwise
            error('Unknown file format');

    end
    
end
  
function face_table = remove_dup_faces(face_table,node_table,hwb)
% Remove faces with coincident centroids and returns surface-faces only

    waitbar(0.7,hwb,'Calculating face centroids');
    n_faces = size(face_table,1);
    c = calc_centroid_mex(face_table,node_table);
    waitbar(0.8,hwb,'Removing internal faces');
    
    % find & remove faces with coincident centroids
    [~,ii,~] = unique(c,'rows','stable'); % ii = index of unique values in c
    repi = setdiff(1:n_faces,ii);   % repi = index of one of the repeated values in c
    repc = c(repi,:);
    [~,idx] = setdiff(c,repc,'rows');
    ufaces = face_table(idx,:); % surface faces
    ucentr = c(idx,:);          % associated centroids
    face_table = [ufaces ucentr];
    
end

function [node_table,elem_table,face_table] = remap(node_table,elem_table,face_table)
% Reduce node, element and face tables so they only include used entities.
% Furthermore remaps nodes to consecutive numbers starting from 1.
% [~,LocB]=ismember(A,B) Locb contains the index in B for each value in A

    face_verts = face_table(:,1:4);
    used_node_idx = unique(face_verts);
    %used_elem_idx = unique(face_table(:,5));
    used_elem_names = unique(face_table(:,5));
    [~,used_elem_idx] = ismember(used_elem_names,elem_table(:,1));
    
    % remove unused nodes & elements
    node_table = node_table(used_node_idx,:);
    elem_table = elem_table(used_elem_idx,:);
    
    % remap vertex entries in face table to point to new node indices
    [~,remapped_verts] = ismember(face_verts,used_node_idx);
    face_table = [remapped_verts face_table(:,5:end)];
    
end

function node2ni = create_node_map(node_table)
    
    % node name -> index
    nodes = node_table(:,1);
    node2ni  = zeros(max(nodes),1,'uint32');
    for ni = 1:size(nodes,1) % ni = internal node number
        n = nodes(ni);       % n  = external node name
        node2ni(n) = ni;
    end
    
end

function mapping = create_number_maps(node_table,elem_table,face_table)
% create maps between different number systems

    n_nodes = size(node_table,1);
    n_elems = size(elem_table,1);
    n_faces = size(face_table,1);
    

    % node name -> index (for surface nodes only)
    node2ni = create_node_map(node_table);
    
    % element name -> index
    elems = elem_table(:,1);
    elem2ei = zeros(max(elems),1,'uint32');
    for ei = 1:size(elems,1) % ei = internal element number
        e = elems(ei);       % e  = external element name
        elem2ei(e) = ei;
    end
    
    
    % face index -> element name
    face2elem = face_table(:,5);
    
   
    % node index -> face no.
    faces = face_table(:,1:4);
    ni2face = zeros(n_nodes,10,'uint32');% node2face(node) = face
    nf = zeros(n_nodes,1,'uint8');
    
    for f = 1:n_faces
        
        if faces(f,3) == faces(f,4)
            fnodes = 3;
        else
            fnodes = 4;
        end
        
        for i = 1:fnodes
            ni = faces(f,i); % current node
            nf(ni) = nf(ni) + 1; % counter
            ni2face(ni,nf(ni)) = f; % current face
        end
        
    end
    
    
    % map node-idx -> connected elem-idx
    ni2ei = zeros(n_nodes,15,'uint32');
    ne = zeros(n_nodes,1,'uint8');
    
    for ei = 1:n_elems
        for i = 4:11 % node numbers in elem_table
            n = elem_table(ei,i); % current node
            if n>0 && n<=length(node2ni)
                ni = node2ni(n);
                if ni>0
                    ne(ni) = ne(ni) + 1; % counter
                    ni2ei(ni,ne(ni)) = ei; % current elem
                end
            end
        end
    end
    
    % return values
    mapping.node2ni   = node2ni;
    mapping.elem2ei   = elem2ei;
    mapping.face2elem = face2elem;
    mapping.ni2face   = ni2face;
    mapping.ni2ei     = ni2ei;
    
end

function [elem_table,face_table,max_dim,model_com,esize]= model_dimensions(elem_table,face_table,entire_model)
% Calculate model dimensions

    % use all nodes in model for these calculations
    node_table = entire_model.node_table;
    node2ni    = entire_model.node2ni;
    
    % find model CoM
    model_com = calc_com_mex(node_table);
    
    % find max dimension
    max_dim = max(range(node_table(:,2:4)));
    
    % find & add element CoM to element table
    elem_table = calc_elem_com_mex(elem_table,node_table,node2ni);
    
    % estimate element side length
    [esize,face_table] = calc_elem_size_mex(node_table,face_table);
   

end

function [node_normals,node_axis] = node_normals(model)
   
    faces   = model.surf.face_table(:,1:4);
    coords  = model.surf.node_table(:,2:4);
    n_nodes = length(coords);
    node_normals = zeros(n_nodes,3,'single');
    node_axis = zeros(n_nodes,3,'single');
    
    for ni = 1:n_nodes
                
        faces_on_node = model.surf.mapping.ni2face(ni,:);
        faces_on_node = faces_on_node(faces_on_node>0);
        all_nodes     = unique(faces(faces_on_node,:));
        
        % fit plane to all nodes on all faces connected to central node:
        X = coords(all_nodes,:);
        p = mean(X,1);
        R = bsxfun(@minus,X,p);
        
        % Computation of the principal directions of the samples cloud
        [V,~] = eig(R'*R);
        
        % surface tangent plane normal
        n = V(:,1);
        
        if 1
            elems_on_node = model.surf.mapping.ni2ei(ni,:);
            elems_on_node = elems_on_node(elems_on_node>0);
            
            % calculate combined COM of attached elements
            ec = [0 0 0]';
            for i = 1:length(elems_on_node)
                ei = elems_on_node(i);
                ec = ec + model.surf.elem_table(ei,12:14)';
            end
            ec = ec/length(elems_on_node);

            % node position
            np = coords(ni,:)';
            
            % if normal points 
            n1 = np + n;
            n2 = np - n;
            if norm(n1-ec) < norm(n2-ec)
                n = -n;
            end
            
        end
        
        % project global x-axis onto plane
        xg = [1 0 0]';
        x = xg - (dot(xg,n)/norm(n))*n;
        
        % if n==x, use y-axis
        if norm(x)==0
            yg = [0 1 0]';
            x = yg - (dot(yg,n)/norm(n))*n;
        end
        
        node_axis(ni,:) = unit(x)';

        % node normal best fit
        node_normals(ni,:) = real(n');
        
    end
        
end

function int_node_table = interior_nodes(model)
% return node_table for interior nodes only.

    all_nodes  = model.entire.node_table(:,1);
    surf_nodes = model.surf.node_table(:,1);
    
    [~,int_node_idx] = setdiff(all_nodes,surf_nodes,'stable');
    int_node_table = model.entire.node_table(int_node_idx,:);
    
end

