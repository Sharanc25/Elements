 function Aj = RotA(Ai,psi,e)
% returns a rotated orientation matrix Aj,
% rotated psi [radians] around vector e from Ai.

    % Euler-parameters:
    e0    = cos(psi/2);
    e1    = e(1)*sin(psi/2); 
    e2    = e(2)*sin(psi/2); 
    e3    = e(3)*sin(psi/2);

    % Euler-parameter transformation matrix (Nikravesh,1988,p.160)
    Aji = 2*[e0^2+e1^2-0.5     e1*e2-e0*e3     e1*e3+e0*e2;
               e1*e2+e0*e3   e0^2+e2^2-0.5     e2*e3-e0*e1;
               e1*e3-e0*e2     e2*e3+e0*e1   e0^2+e3^2-0.5];

    % Update A matrix of current body
    Aj = Ai*Aji;
    
end