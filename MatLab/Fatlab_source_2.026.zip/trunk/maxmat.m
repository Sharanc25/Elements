function [maxA,i,j] = maxmat(A)

    [maxA,i] = max(A);
    [maxA,j] = max(maxA);
    i = i(j);

end