function LC = reduce_to_turning_points(LC,threshold)
% reduce loads to turning points (peak/valleys)

n_comps = length(LC(1).Lcomps);

for lc = 1:length(LC);

    ti = [];
    tp = [];
    Lp = [];
    
    for i = 1:n_comps
        
        [Lpi,tpi] = sig2ext_time(LC(lc).L(:,i));
        
        if threshold>0
            [Lpi,tpi] = race_track_filter_time(Lpi,tpi,threshold*range(Lpi));
        end
        
        % gather list to extrema
        ti = [ti; tpi];
        tp{i} = tpi;
        Lp{i} = Lpi;

    end
    
    % indices of all extrema
    ti = unique(ti); 
    n_peaks = length(ti);

    % reduced load-time series
    LC(lc).L = zeros(n_peaks,n_comps,'single');
    for c = 1:n_comps
        if length(Lp{c})>1 % non-flat signal
            LC(lc).L(:,c) = interp1(tp{c},Lp{c},ti,'linear','extrap')';
        end
    end
    
    % reduced time axis
    LC(lc).t = LC(lc).ti(int32(ti+1));
    
end