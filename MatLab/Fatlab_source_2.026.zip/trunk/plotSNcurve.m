function hp = plotSNcurve(ds1,N1,N2,m1,m2,maxS,minS,gf,varargin)
    
    % calculate fatigue capacities
    C1 = ds1^m1*N1;
    ds2 = (C1/N2)^(1/m1);
    C2 = ds2^m2*N2;
    NmaxS = C1/maxS^m1;
    NminS = C2/minS^m2;

    % make N vector: 1 -> Nmax
    Nmax = 1e10;
    N = 1;
    i = 2;
    while N(i-1)<Nmax
        N(i) = N(i-1)*1.25;
        i = i + 1;
    end
    N(end) = Nmax;
    N = sort([N N1 N2]);

    % calc corresponding S values
    i = 0;
    for Ni=N
        i = i+1;
        if Ni<NmaxS
            S(i) = maxS;
        elseif Ni>=NmaxS && Ni<N2
            S(i) = (C1/Ni)^(1/m1);
        elseif Ni>=N2 && Ni<NminS
            S(i) = (C2/Ni)^(1/m2);
        else % Ni>=NminS
            if minS<S(i-1)
                S(i) = minS;
            else
                S(i) = S(i-1);
            end
        end
    end

    Sg = S.*1/gf;
    ds2gf = ds2/gf;
    
    % plot
    loglog(N,S,'r--','linewidth',1); hold on
    hp = loglog(N,Sg,'r','linewidth',1);
    %loglog([NminS NmaxS],[minS maxS],'r.','markersize',11);
    xlim([1000 1e10])
    ylim([1 3000])
    xlabel('Fatigue life, N_f [cycles]')
    ylabel('Stress range, \Delta\sigma [MPa]')
    loglog(N1,ds1,'or','linewidth',1,'markerfacecolor','w','markersize',5);
    loglog(N2,ds2gf,'or','linewidth',1,'markerfacecolor','w','markersize',5);

    if nargin==8
        set(gca,'Yticklabel',[1 10 100 1000]);
        
        % slopes
        text(1.2*N1,1.1*ds1,num2str(round(ds1)),'horizontalalignment','left');

        text(0.98*N2,0.98*ds2gf,num2str(round(ds2gf)),'horizontalalignment','right','verticalalignment','top');

        k = 50;
        loglog([N(k) N(k) N(k+5)],[Sg(k) Sg(k+5) Sg(k+5)],'-k');
        text(N(k+2),Sg(k+5),['m_1=' num2str(m1)],'horizontalalignment','center','verticalalignment','top','fontsize',8);
        k = find(N>N2,1)+1;
        loglog([N(k) N(k) N(k+5)],[Sg(k) Sg(k+5) Sg(k+5)],'-k');

        % ds@2e6
        text(N(k+2),Sg(round(k+5)),['m_2=' num2str(m2)],'horizontalalignment','center','verticalalignment','top','fontsize',8);

        title('SN curve')
    end
end
