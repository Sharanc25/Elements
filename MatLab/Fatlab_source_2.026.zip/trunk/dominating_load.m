function [D,Lcomps]= dominating_load(node_no,lc_no,FE,LC,SN,options,model,results)
% Find the dominating load component

n_loads = options.n_loads;
Lcomps  = LC(1).Lcomps;
D = zeros(n_loads,1);

for i = 1:n_loads

    load_type = FE(1).load_table(i,1);
    
    if load_type < 5
        
        % modify FE: disable all but current load components
        FEmod = FE;
        FEmod(1).load_table(:,1) = 0;
        FEmod(1).load_table(i,1) = load_type;
        
        % do fatigue calulations
        res = fatigue_calc(FEmod,LC(lc_no),SN,options,model,results,node_no);
        D(i) = res.Dtot(node_no);

    end
    
end
