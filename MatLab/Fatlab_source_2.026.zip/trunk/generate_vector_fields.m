function stress = generate_vector_fields(node,node_coords,max_mag,esize,scale_vec)%#codegen
% generate vector fields for plotting

    n_steps = size(node(1).mag,1);
    n_nodes = size(node_coords,1);
    
    structure = struct('mag',zeros(3,n_nodes,'single'), ...
                       'p1',zeros(3,3*n_nodes,'single'),...
                       'p2',zeros(3,3*n_nodes,'single'),...
                       'p3',zeros(3,3*n_nodes,'single'),...
                       'pm',zeros(3,3*n_nodes,'single'));
	stress = repmat(structure,1,n_steps);

    for t = 1:n_steps
        
        for n = 1:n_nodes
        
            mag_j   = node(n).mag(t,:)';
            dir_j   = node(n).dir(t,:)';
            pmdir_j = node(n).pmdir(t,:)';
            pi      = node(n).pi(t,:)';

            if scale_vec
                scale = 0.5*esize * (mag_j/max_mag);
                pmscale = max(abs(scale));
            else 
                scale = 0.5*[1 1 1]'*esize;
                pmscale = scale(1);
            end

            A = BryantTrMat(dir_j');
            p = node_coords(n,:)';

            p1 = A(:,pi(1))*scale(1);
            p2 = A(:,pi(2))*scale(2);
            p3 = A(:,pi(3))*scale(3);
            
            stress(t).mag = mag_j;
            stress(t).p1(1:3, (n*3-2):(n*3) ) = [p-p1 p+p1 [NaN NaN NaN]'];
            stress(t).p2(1:3, (n*3-2):(n*3) ) = [p-p2 p+p2 [NaN NaN NaN]'];
            stress(t).p3(1:3, (n*3-2):(n*3) ) = [p-p3 p+p3 [NaN NaN NaN]'];

            pm = pmscale * pmdir_j;
            stress(t).pm(1:3, (n*3-2):(n*3) ) = [p-pm p+pm [NaN NaN NaN]'];
        end
       
    end
    
end

% coder -build generate_vector_fields.prj