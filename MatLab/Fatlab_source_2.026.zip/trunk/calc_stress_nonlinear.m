function S = calc_stress_nonlinear(load_table,ULC_table,stress_table,F) %#codegen
% Generate stress tensor time series S [n_time_steps,6].
%  load_table   = [load_type fromULC toULC n_ULCs , n_loads] (int8)
%  ULC_table    = [load_no load_val var_val , n_ULCs] (single)
%  stress_table = [Sxx Syy Szz Txy Txz Tyz, n_ULCs] (single)
%  F            = load-time series [time_steps,load_components]

    % initialize
    [n_step,n_loads] = size(F); % no of time steps (can vary between LCs)
    S = coder.nullcopy(zeros(n_step,6,'single')); % all stress components

    % stress components for each ULC
    max_ULCs_per_load = max(load_table(:,4));
    ULC_stress2D = zeros(max_ULCs_per_load,'single');
    

    % calculate stress-time series by superposition of different types of load contributions
    for i = 1:n_loads

        Fi = F(:,i);
        load_type = load_table(i,1);
        fromULC   = load_table(i,2);
        toULC     = load_table(i,3);
        
        switch load_type
            
            case 1 % linear
               
                % one ULC onlym fromULC = toULC
                ULC_load   = ULC_table(fromULC,2);
                ULC_stress = stress_table(fromULC,:);
                
                Fi = F(:,i)/ULC_load;
                S  = S + Fi*ULC_stress;

            case 2 % bi-linear
                
                ULC_load_neg   = ULC_table(fromULC,2);
                ULC_load_pos   = ULC_table(toULC,2);
                
                ULC_stress_neg = stress_table(fromULC,:);
                ULC_stress_pos = stress_table(toULC,:);
                
                neg_loads = ((Fi<0).*Fi)/ULC_load_neg;
                pos_loads = ((Fi>0).*Fi)/ULC_load_pos;

                S = S + pos_loads * ULC_stress_pos ... % positive
                      + neg_loads * ULC_stress_neg;    % negative

            case 3 % 1D interpolation
                
                ULC_loads = ULC_table(fromULC:toULC,2);
                
                for s = 1:6 % interpolate one stress component at the time
                    
                    ULC_stress1D = stress_table(fromULC:toULC,s);
                    
                    % query all time steps at once
                    S(:,s) = S(:,s) + interp1(ULC_loads,ULC_stress1D,Fi,'linear','extrap');
                    
                end
                
            case 4 % 2D interpolation
                
                Vi = F(:,i+1); % variable associated with Fi, e.g. angle
                
                Fsu = unique(ULC_table(fromULC:toULC,2)); % load val
                Vsu = unique(ULC_table(fromULC:toULC,3)); % var val
                                
                for s = 1:6 % interpolate one stress component at the time
                    
                    for u = fromULC:toULC
                        h = Fsu==ULC_table(u,2);
                        k = Vsu==ULC_table(u,3);
                        ULC_stress2D(k,h) = stress_table(u,s); 
                    end
                    
                    S(:,s) = S(:,s) + interp2(Fsu,Vsu,ULC_stress2D(1:length(Vsu),1:length(Fsu)),Fi,Vi);
                    
                end
                
        end
                
    end

end





