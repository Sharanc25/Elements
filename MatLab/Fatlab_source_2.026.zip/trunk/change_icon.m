function change_icon(fig_handle,icon_file)
% change the figure icon.

    warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

    jframe=get(fig_handle,'javaframe');
    jIcon=javax.swing.ImageIcon(icon_file);
    jframe.setFigureIcon(jIcon);

end