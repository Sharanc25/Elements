function gegrees = rad2deg(radians)

gegrees = (180/pi) * radians;
