function face_table = generate_faces(node2idx,elem_table,elem_types)% #codegen
% Generates table of faces for all elements
% incl. map of facenumber to element index

    % mapping of nodes on tet/hex elements to faces
    tetmap  = [1 2 3 3; 1 2 4 4; 1 3 4 4; 2 3 4 4]; % use 4 vertices for tet faces also.
    hexmap  = [1 2 3 4; 1 2 6 5; 2 3 7 6; 3 7 8 4; 1 4 8 5; 5 6 7 8];
    quadmap = [1 2 3 4];

    % face table: [node_idx1, node_idx2, node_idx3, node_idx4, elem_name]
    n_elems = size(elem_table,1);
    face_table = zeros(6*n_elems,5,'single');
    f = 0;
    
    for ei = 1:n_elems

        % get element type specifics
        cur_elem_type = elem_table(ei,2);
        elem_name     = elem_table(ei,1);
        
        switch elem_types(cur_elem_type)
            case {1,3} % 'TETRA10' / 'SOLID187' (tet)
                nodes   = elem_table(ei,4:7);
                fmap    = tetmap;
                n_faces = 4;
                
            case 2 % 'SOLID186' (hex)
                nodes   = elem_table(ei,4:11);
                fmap    = hexmap;
                n_faces = 6;
                
            case {4,5} % 2D quad/triangle/shell
                nodes   = elem_table(ei,4:7);
                fmap    = quadmap;
                n_faces = 1;
                
            otherwise
                n_faces = 0;
        end
        
        % build face table
        for no = 1:n_faces
            f = f + 1;
            face_table(f,1:4) = node2idx(nodes(fmap(no,:)))';
            face_table(f,5)   = elem_name;
        end
        
    end
    
    % remove unused entries
    face_table(face_table(:,1)==0,:) = [];
    
end

% coder -build generate_faces.prj