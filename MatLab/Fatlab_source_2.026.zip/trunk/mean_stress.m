function ds2 = mean_stress(sm,SN)%#codegen
% Calculates the allowable stress range (ds2), 
% depending on the current mean stress (sm).

sa2 = SN.ds2/2;
M   = SN.M;
Re  = SN.Re;
Rm  = SN.Rm;


% select mode:
mean_mode = SN.mean_mode; % {'None' 'Linear' 'Bilinear' 'Soderberg' 'Modified Goodman' 'Gerber parabola' 
                          % 'Smith-Watson-Topper' '60% Compression' 'IIW low RS', 'IIW medium RS' 'FKM'}

% additional options
observe_yield_lines     = SN.mean_yield;
extrapolate_compression = SN.mean_comp;


% calculate allowable stress amplitude 
switch lower(mean_mode)
    case 1 % none
        sa = sa2;

    case 2 % linear
        sa = sa2 - M*sm; % Radaj & Vormwald, 2007, p.32.

    case 3 % bilinear % from Gudehus & Zenner
        sa_R0 = sa2/(1+M); % allowable stress ampl. at R=0. Identical to corresponding mean stress
        
        if sm <= sa_R0
            sa = sa2 - M*sm; % Linear correction
        else % Modified Goodman
            sa = sa_R0*(Rm - sm)/(Rm - sa_R0);
        end
        
    case 4 % Soderberg
        sa = sa2 * (1-sm/Re);

    case 5 % Modified goodman 
        sa = sa2 * (1-sm/Rm);

    case 6 % Gerber's parabola
        sa = sa2 * (1-sm^2/Rm^2);
        if sm < 0
            sa = sa2;
        end
        
    case 7 % Smith-Watson-Topper
%         sa = sm/2 * (sqrt((2*sa2/sm)^2+1) -1);
%         sa = -sm/2 + sqrt(sm^2+4*sa2^2)/2;
        sa = -0.5*(sm - sqrt(sm^2+4*sa2^2));
        if sm <= 0
            sa = sa2;
        end
        
    case 8 % 60% compression rule of DNVGL RP-0005-2014, p.27
        if sm < -sa2/0.6
            sa = sa2/0.6;
        elseif sm >= -sa2/0.6 && sm <= sa2
            sa = 1.25*sa2 -0.25*sm;
        else % sm > sa2
            sa = sa2;
        end
        
    case 9 % 'IIW low RS,  IIW rec. p. 79 (2013 ed)
        if sm < 0 % R<-1
            fR = 1.6;
        elseif sm >= 0 && sm <= 3*sa2 % R>-1 & R<0.5
            fR = (-0.6/(3*sa2))*sm + 1.6;
        else % R>=0.5
            fR = 1;
        end
        
        sa = fR * sa2;

    case 10 % IIW medium RS
        if sm < 0 % R<-1
            fR = 1.3;
        elseif sm >= 0 && sm <= 3*sa2 % R>-1 & R<0.5
            fR = (-0.3/(3*sa2))*sm + 1.3;
        else % R>=0.5
            fR = 1;
        end
        
        sa = fR * sa2;
        
    case 11 % FKM guideline
        sa_R0  = sa2/(1+M);
        sa_Rni = sa2/(1-M);
        sm_R05 = sa_R0*(3+M)/(1+M);
        
        if sm <= -sa_Rni
            sa = sa_Rni;
        elseif sm>-sa_Rni && sm < sa_R0
            sa = sa2 - M*sm;
        elseif sm >= sa_R0 && sm < sm_R05
            sa = sa_R0*(1+M/3) - M/3*sm;
        else
            sa = sm_R05/3;
        end
        
    otherwise
        sa = sa2;
        
end

% extrapolate in compresssion?
if ~extrapolate_compression && (sm < 0) && (mean_mode < 8)
    sa = sa2;
end

% avoid yielding?
if observe_yield_lines
    for i = 1:length(sm)
        if sm <= 0
            yield_line = Re + sm;
        else
            yield_line = Re - sm;
        end
        sa = min(yield_line,sa);
    end
end

% return as range
ds2 = 2*sa;