function [normals,plane1] = vert_norm_planefit(faces,nodes)

    all_verts = [faces(:,1); faces(:,2); faces(:,3); faces(:,4)]';
    vertices = unique(all_verts);
    nv       = length(vertices);
    normals  = zeros(nv,3);
    
    for i = 1:nv

        v = vertices(i);
        f = find(any(ismember(faces,v),2));

        all_v = [];
        for j = 1:length(f)
            all_v = [all_v faces(f(j),:)];
        end
        all_v = unique(all_v);
        
        X = nodes(all_v,2:4);
        p = mean(X,1);
    
        % The samples are reduced:
        R = bsxfun(@minus,X,p);
        
        % Computation of the principal directions if the samples cloud
        [V,~] = eig(R'*R);
        
        % Extract the output from the eigenvectors
        n  = V(:,1);
        p1 = V(:,2);
        normals(i,:) = real(n');
        plane1(i,:)  = real(p1');

    end

end
