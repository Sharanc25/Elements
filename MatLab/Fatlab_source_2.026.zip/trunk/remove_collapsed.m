function face_table = remove_collapsed(face_table)
% Remove collapsed faces, i.e. faces where multiple vertex numbers 
% refer to the same nodes. E.g. face = point or face = line.

    n_faces = size(face_table,1);
    unique_nodes_on_face = zeros(n_faces,1,'uint32');
    
    for f = 1:n_faces
        
        unique_nodes_on_face(f) = length(unique(face_table(f,1:4)));
        
    end
    
    collapsed = [find(unique_nodes_on_face==1); 
    find(unique_nodes_on_face==2)];
    face_table(collapsed,:) = [];
    
end