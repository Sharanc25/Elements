function [dS, Sm] = rainflow_Gong(S)
% Rainflow counter using the algorithm of
%   S.D. Downing and D. F. Socie, 'Simple rainflow algorithm',
%   International jounrnal of fatigue, Vol. 4, No. 1, 31-40, 1982.
%
% INPUT
%   S: column vector containing the stress signal
%
% OUTPUT
%   dS: vector of stress ranges (one row per extracted cycle)
%   Sm: vector of mean stress (one row per extracted cycle)
%
% Original by Yu Gong, gongyu2000@gmail.com.
% Modified by MMP, 04-10-2016.
%


% extract peak/valleys from stress signal
valley = find(diff(sign(diff(S))) > 0) + 1;
peak = find(diff(sign(diff(S))) < 0) + 1;
Spv(1) = S(1);
Spv(2 : length(S(union(valley,peak))) + 1) = S(union(valley,peak));
Spv(end + 1) = S(end);
Spv = Spv';

% break if signal is too short to count
if length(Spv) < 4
    error('Signal contains too few extrema to count.')
end

% initialize arrays used later
max_cycles = length(Spv);
E  = zeros(1,max_cycles);
dS = zeros(1,max_cycles);
Sm = zeros(1,max_cycles);

% re-arrange signal (signal is cut at the highest peak the latter part of 
% the signal is moved to the front, such that the new signal starts- and 
% ends with the highest peak).
[Cmax,Imax] = max(Spv);
if mod(length(Spv),2)
    if xor(Spv(1) > Spv(2), Spv(1) >= Spv(end))
        Spv(1) = [];
        Spv = circshift(Spv, 2 - Imax);
    else
        Spv(end) = [];
        Spv = circshift(Spv, 1 - Imax);
    end
else
    if xor(Spv(1) > Spv(2), Spv(1) >= Spv(end))
        Spv(1) = [];
        Spv(end) = [];
        Spv = circshift(Spv, 2 - Imax);
    else
        Spv = circshift(Spv, 1 - Imax);
    end
end
Spv(end + 1) = Cmax;    


% start rainflow counting procedure
i = 0;
j = 0;
while ~isempty(Spv)

    j = j + 1;
    E(j) = Spv(1);
    Spv(1) = [];

    while j >= 3
        
        X = abs(E(j) - E(j - 1));
        Y = abs(E(j - 1) - E(j - 2));

        if X < Y 
            break % skip remaining part of loop and go to next iteration 
        end

        i = i + 1;
        dS(i) = Y;
        Sm(i) = (E(j - 1) + E(j - 2))/2;
        
        j = j - 2;
        E(j) = E(j + 2);
        
    end
end

% trim unused parts of output arrays
dS(i+1:end) = [];
Sm(i+1:end) = [];
