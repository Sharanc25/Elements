function dSeq = equivalent_stress(rf,m,varargin)
% Damage equivalent stress calculation

dS = rf(1,:);
n  = rf(4,:);

if nargin==2
    N = sum(n);
else
    N = varargin{1};
end

dSeq = 0;
for i = 1:size(rf,2)
	dSeq = dSeq + dS(i)^m*n(i);
end
dSeq = (dSeq/N)^(1/m);
