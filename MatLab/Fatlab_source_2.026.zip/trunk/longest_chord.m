function [mT,aTn,Tn1_max,Tn2_max] = longest_chord(Tu,Tv)
% determine shear stress mean and amplitude on plane, after Lemaitre

t_max = length(Tu);
dTn_max = single(0);
Tn1_max = single(0);
Tn2_max = single(0);
T = [Tu'; Tv'];

for t1 = 1:t_max

    Tn1 = T(:,t1);

    for t2 = 1:t_max
        
        Tn2 = T(:,t2);
        dTn = norm(Tn1-Tn2);
        
        if dTn > dTn_max
            dTn_max = dTn;
            Tn1_max = Tn1;
            Tn2_max = Tn2;
        end
        
    end
    
end

aTn = norm(Tn1_max-Tn2_max)/2;
mT  = norm(Tn1_max+Tn2_max)/2;

% coder -build longest_chord.prj