function stress_table = calc_nodal_stresses(ElemTableCornerNodes) %#codegen

% extract results + convert to MPa
elem2node = ElemTableCornerNodes([1  9 17 25],:);
SX        = ElemTableCornerNodes([2 10 18 26],:)/1e6;
SY        = ElemTableCornerNodes([3 11 19 27],:)/1e6;
SZ        = ElemTableCornerNodes([4 12 20 28],:)/1e6;
TXY       = ElemTableCornerNodes([5 13 21 29],:)/1e6;
TXZ       = ElemTableCornerNodes([6 14 22 30],:)/1e6;
TYZ       = ElemTableCornerNodes([7 15 23 31],:)/1e6;

n_nodes = max(max(elem2node));
n_elems = size(elem2node,2);

% average nodal stresses
node_list = zeros(n_nodes,1,'single');
elements_on_node = zeros(n_nodes,1,'single');
SX_avg = zeros(n_nodes,1,'single');
SY_avg = zeros(n_nodes,1,'single');
SZ_avg = zeros(n_nodes,1,'single');
TXY_avg = zeros(n_nodes,1,'single');
TXZ_avg = zeros(n_nodes,1,'single');
TYZ_avg = zeros(n_nodes,1,'single');

for e = 1:n_elems    
    for n = 1:4 % corner nodes only        
        node = elem2node(n,e);        
        elements_on_node(node) = elements_on_node(node) + 1;
        node_list(node) = node;
        SX_avg(node)  = SX_avg(node)  + SX(n,e);
        SY_avg(node)  = SY_avg(node)  + SY(n,e);
        SZ_avg(node)  = SZ_avg(node)  + SZ(n,e);
        TXY_avg(node) = TXY_avg(node) + TXY(n,e);
        TXZ_avg(node) = TXZ_avg(node) + TXZ(n,e);
        TYZ_avg(node) = TYZ_avg(node) + TYZ(n,e);
    end
end

% Result matrix [NodeNo SX SY SZ TXY TXZ TYZ]
stress_table = zeros(n_nodes,7,'single');
stress_table(:,1) = node_list;
stress_table(:,2) = SX_avg./elements_on_node;
stress_table(:,3) = SY_avg./elements_on_node;
stress_table(:,4) = SZ_avg./elements_on_node;
stress_table(:,5) = TXY_avg./elements_on_node;
stress_table(:,6) = TXZ_avg./elements_on_node;
stress_table(:,7) = TYZ_avg./elements_on_node;

% remove empty entries
stress_table(stress_table(:,1)==0,:) = [];

% coder -build calc_nodal_stresses.prj
