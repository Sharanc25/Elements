function nodelist = read_nodelist(filename,format)

    switch format
        case 'simulation' %csv
            fid  = fopen(filename);
            file = textscan(fid,'%s','delimiter',sprintf('\n'),'whitespace',' ','headerlines',7);
            file = file{1};

            cnodelist = cellfun(@get_node_no,file,'UniformOutput',false);
            nodelist  = cell2mat(cnodelist);

        case 'ansys' %txt
            fid  = fopen(filename);
            i = 1;
            nodelist = [];
            while ~feof(fid)
                line  = strtrim(fgetl(fid));
                words = strsplit(line,' ');
                node  = str2num(words{1});
                if ~isempty(node) && isnumeric(node)
                    nodelist(i,1) = node;
                    i = i + 1;
                end
            end
            
    end

    fclose all;
    
end

function node = get_node_no(line)

    first_comma = find(line==',',1);
    node = str2num(line(1:first_comma-1));
    
end
