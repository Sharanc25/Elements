function [LC,options] = setup_loads(LC,options)

    global hs
    
    % setup gui
    hs.fig = figure('name','Setup loads','NumberTitle','off','toolbar','figure','menu','none','color',[0.941176 0.941176 0.941176],...
                    'units','characters','position', [4 5 250 60],'WindowKeyPressFcn',@ok_cancel);
    change_icon(hs.fig,'icon.png');
    center_gui(hs.fig);
    
    % hide unsed toolbar buttons
    hs.tb  = findall(hs.fig,'tag','FigureToolBar');
    hs.tbb = findall(hs.tb); 
    delete(hs.tbb([2:7 9 13:end]))
    hs.tbb(12).Separator = 'off';
   
    % store current values
    setappdata(hs.fig,'LC',LC);
    setappdata(hs.fig,'options',options);
    setappdata(hs.fig,'selectedLC',1);
    
    % primary plot axes
    hs.ax1 = axes('pos',[0.05 0.46 0.9 0.5]);
    ylabel('Load');
    xlabel('Time');
    
    
    % LC selection panel
    hs.pan2 = uipanel('pos',[0.05 0.05 0.57 0.35],'bordertype','none');
    hs.txt  = uicontrol('Style','text','String','Load cases:','units','normalized','pos',[0.0 0.96 0.3 0.05],'parent',hs.pan2,'horizontalalignment','left');

    columnname   = {'Name' 'Repetitions'};
    columnedit   = [ false  true];
    columnwidth  = {    75     70};
    columnformat = {'char','numeric'};
    hs.LCtable = uitable('ColumnName', columnname,'ColumnFormat', columnformat,...
                         'ColumnEditable',columnedit,'parent',hs.pan2,'units','normalized',...
                         'ColumnWidth',columnwidth,'pos',[0.0 0.0 0.258 0.95],...
                         'CellEditCallback',@cb_editLC,'CellSelectionCallback',@cb_selectLC);
        
    % load component table
    hs.txt  = uicontrol('Style','text','String','Load components:','units','normalized','pos',[0.27 0.96 0.3 0.05],'parent',hs.pan2,'horizontalalignment','left');
    columnname   = {'Name' 'Unit' 'Min' 'Max' 'Mean' 'Cycles' 'DEL' 'Scale' 'Offset' 'Plot'};
    columnedit   = [ false  false false false  false    false false    true     true   true];
    columnwidth  = {    70     35    50    50     50       55    50      40       40     40};
    columnformat = {'char','char','bank','bank','bank','bank','bank','numeric','numeric','logical'};
    hs.table = uitable('ColumnName', columnname,'ColumnFormat', columnformat,...
                       'ColumnEditable',columnedit,'parent',hs.pan2,'units','normalized',...
                       'ColumnWidth',columnwidth,'pos',[0.27 0.0 0.73 0.95],...
                       'CellEditCallback',@cb_selectComp);
    
    % file & options panel
    hs.pan1   = uipanel('pos',[0.64 0.05 0.32 0.35],'bordertype','none');
    
    hs.txt    = uicontrol('Style','text','String','Loads file:','units','normalized','pos',[0.0 0.96 0.3 0.05],'parent',hs.pan1,'horizontalalignment','left');
    hs.edit   = uicontrol('Style','edit','String','','units','normalized','pos',[0.0 0.85 0.8 0.085],'parent',hs.pan1,'horizontalalignment','left','backgroundcolor','w');
    hs.select = uicontrol('Style','pushbutton','string','Browse...','units','normalized','pos',[0.81 0.845 0.15 0.095],'parent',hs.pan1,'callback',@cb_selectLoads);
    hs.update = uicontrol('Style','pushbutton','string','Update','units','normalized','pos',[0.81 0.75 0.15 0.095],'parent',hs.pan1,'callback',@cb_read_loads);
    
    hs.txt    = uicontrol('Style','text','String','Plot type:','units','normalized','pos',[0.0 0.75 0.3 0.05],'parent',hs.pan1,'horizontalalignment','left');
    hs.ptype  = uicontrol('Style','popupmenu','string',{'Load-time series','Frequency content (FFT)'},...
        'units','normalized','pos',[0.24 0.735 0.3 0.095],'parent',hs.pan1,'callback',@cb_update_plot,'backgroundcolor','w');
    hs.txt    = uicontrol('Style','text','String','Cycle counter:','units','normalized','pos',[0.0 0.66 0.3 0.05],'parent',hs.pan1,'horizontalalignment','left');
    hs.ctype  = uicontrol('Style','popupmenu','string',{'Reservoir'},'units','normalized','pos',[0.24 0.65 0.3 0.085],'parent',hs.pan1,'callback',@cb_update_gui,'backgroundcolor','w','Enable','off');
    
    hs.txt    = uicontrol('Style','text','String','DEL calculation: m=','units','normalized','pos',[0.0 0.57 0.3 0.05],'parent',hs.pan1,'horizontalalignment','left');
    hs.slope  = uicontrol('Style','edit','String','4','units','normalized','pos',[0.24 0.55 0.075 0.085],'parent',hs.pan1,'horizontalalignment','right','backgroundcolor','w','callback',@cb_update_gui);
    hs.txt    = uicontrol('Style','text','String','@ N=','units','normalized','pos',[0.32 0.57 0.3 0.05],'parent',hs.pan1,'horizontalalignment','left');
    hs.cycles = uicontrol('Style','edit','String','1','units','normalized','pos',[0.41 0.55 0.13 0.085],'parent',hs.pan1,'horizontalalignment','right','backgroundcolor','w','callback',@cb_update_gui);
    hs.txt    = uicontrol('Style','text','String','cycles','units','normalized','pos',[0.54 0.57 0.3 0.05],'parent',hs.pan1,'horizontalalignment','left');
    
    hs.mark   = uicontrol('Style','checkbox','String','Show data markers','units','normalized','pos',[0.0 0.34 0.8 0.085],'parent',hs.pan1,'horizontalalignment','left','callback',@cb_update_plot);
    hs.txt    = uicontrol('Style','text','String','Load reduction?','units','normalized','pos',[0. 0.465 0.3 0.05],'parent',hs.pan1,'horizontalalignment','left');
    hs.reduce = uicontrol('Style','popupmenu','String',{'Full time series' 'All turning points' 'Race track filter 5%' 'Race track filter 10%' 'Race track filter 20%' 'Race track filter 30%' 'Race track filter 40%' 'Single cycle DEL'},...
        'units','normalized','pos',[0.24 0.45 0.3 0.085],'value',options.reduced_loads,'parent',hs.pan1,'horizontalalignment','left','callback',@cb_reduce,'backgroundcolor','w');
    
    % OK/cancel
    hs.cancel = uicontrol('Style','pushbutton','string','Cancel','units','normalized','pos',[0.65 0.0 0.15 0.095],'parent',hs.pan1,'callback',@cb_cancel);
    hs.ok     = uicontrol('Style','pushbutton','string','OK','units','normalized','pos',[0.81 0.0 0.15 0.095],'parent',hs.pan1,'callback',@cb_ok);
 
    cb_reduce()
    update_gui()
    
    hs.ok_pressed = false;
    uicontrol(hs.ok)
    uiwait(hs.fig);
    
    if hs.ok_pressed
        LC      = getappdata(hs.fig,'LC');
        options = getappdata(hs.fig,'options');
        close(hs.fig);
    end
    
end

function ok_cancel(~,event)

    if strcmp(event.Key,'escape')
        cb_cancel();
    elseif strcmp(event.Key,'return')
        %cb_ok();
    end

end

function update_gui()

    global hs
    LC = getappdata(hs.fig,'LC');
    
    if isempty(LC)
        return;
    end
    
    options = getappdata(hs.fig,'options');
    selectedLC = getappdata(hs.fig,'selectedLC');
    
    % loads file
    set(hs.edit,'string',options.files.loads_file);
    
    % build LC table
    LCtable = cell(length(LC),2);
    for i=1:length(LC)
        LCtable{i,1} = LC(i).desc;
        LCtable{i,2} = LC(i).n;
    end
    set(hs.LCtable,'data',LCtable);

    % build load component table
    Neq = str2num(get(hs.cycles,'string'));
    [N,DEL] = calc_LC_DELs(LC(selectedLC),Neq);
    n_comps = length(LC(selectedLC).Lcomps);
    table   = cell(n_comps,7);
    for j=1:n_comps
        table{j,1}  = LC(selectedLC).Lcomps{j};
        table{j,2}  = LC(selectedLC).Lunits{j};
        table{j,3}  = min(LC(selectedLC).L(:,j));
        table{j,4}  = max(LC(selectedLC).L(:,j));
        table{j,5}  = mean(LC(selectedLC).L(:,j));
        table{j,6}  = N(j);
        table{j,7}  = DEL(j);
        table{j,8}  = LC(selectedLC).scale(j);
        table{j,9}  = LC(selectedLC).offset(j);
        table{j,10} = LC(1).plot(j);
    end
    set(hs.table,'data',table);
    
    update_plot();
    
end

function [N,DEL,AVG]=calc_LC_DELs(LC,Neq)
    
    global hs
    n_comps = length(LC.Lcomps);
    m   = str2num(get(hs.slope,'string'));
    N   = zeros(n_comps,1);
    DEL = zeros(n_comps,1);
    AVG = zeros(n_comps,1);
    
    for i=1:n_comps
        
        % cycle counting
        extremes = sig2ext_mex(LC.L(:,i));
        %         if length(extremes)>1 % filter away small stress cycles
        %             extremes = race_track_filter(extremes,k);
        %         end
        switch get(hs.ctype,'value')
            case 1 %'Reservoir'
                rf = reservoir_counting_mex(extremes);
            case 2 %'Rainflow'
                rf = rainflow(extremes);
        end
        
        ranges = rf(1,:);
        cycles = rf(4,:);
        
        N(i)   = sum(cycles);
        DELsum = sum(cycles.*ranges.^m);
        DEL(i) = ( DELsum/Neq ).^(1/m);
        AVG(i) = mean(LC.L(:,i));
        
    end

end

function cb_update_gui(~,~)
    update_gui();
end

function cb_update_plot(~,~)
    update_plot();
end

function update_plot()

    global hs
    
    selectedLC = getappdata(hs.fig,'selectedLC');
    LC = getappdata(hs.fig,'LC');
    curLC = LC(selectedLC);
    
    table = get(hs.table,'data');
    iplot = cell2mat(table(:,10));
    np = length(iplot);
    cols = colormap(lines(np));
    
    axes(hs.ax1);
    cla; hold on;
    title(['Load case ' num2str(selectedLC) ': ' LC(selectedLC).desc]);
    plot([curLC.t(1) curLC.t(end)],[0 0],'k');
    hp = []; leg = [];
    
    for i = 1:np
        if iplot(i)
            
             switch get(hs.ptype,'value')
                 case 1 % Time series
                    hp(end+1)  = plot(curLC.t,curLC.L(:,i),'color',cols(i,:));
                    if get(hs.mark,'value') % plot markers
                        plot(curLC.t,curLC.L(:,i),'.','color',cols(i,:));
                    end
                    xlabel('Time');
                    ylabel('Load');
                    xlim([curLC.t(1) curLC.t(end)]); 
                
                 case 2 % FFT
                    values = curLC.L(:,i);
                    dt = curLC.t(2)-curLC.t(1);
                    Fs = 1/dt;
                    fft_plot = fft(values);
                    L = length(values);
                    NFFT = 2^nextpow2(L);
                    Y = fft(values,NFFT)/L;
                    f = Fs/2*linspace(0,1,NFFT/2+1);
                    hp(end+1) = plot(f,2*abs(Y(1:NFFT/2+1)),'color',cols(i,:));
                    ylabel('FFT amplitude spectrum')
                    xlabel('Frequency');
                    xlim([0 max(f)]);
                
             end
             
             leg{end+1} = curLC.Lcomps{i};
             
        end
    end
    
    if ~isempty(hp)
        hl = legend(hp,leg);
    end
    
end

function cb_selectLC(~,event)
    
    global hs
    selectedLC = event.Indices(1);
    setappdata(hs.fig,'selectedLC',selectedLC);
    
    update_gui();

end

function cb_editLC(~,event)
    
    global hs
    
    LC = getappdata(hs.fig,'LC');
    
    selectedLC = event.Indices(1);
    newNoRep   = event.NewData;
    
    % update no. of repetitions
    LC(selectedLC).n = newNoRep;
    
    setappdata(hs.fig,'LC',LC);

end

function cb_selectComp(~,~)

    global hs
    selectedLC = getappdata(hs.fig,'selectedLC');
    LC = getappdata(hs.fig,'LC');

    table   = get(hs.table,'data');
    iscale  = cell2mat(table(:,8));
    ioffset = cell2mat(table(:,9));
    iplot   = cell2mat(table(:,10));
    
    LC(1).plot = iplot;   
    LC(selectedLC).scale  = iscale;   
    LC(selectedLC).offset = ioffset;   
    
    setappdata(hs.fig,'LC',LC);
    cb_reduce();
    
end

function cb_reduce(~,~)

    global hs
    LC      = getappdata(hs.fig,'LC');
    options = getappdata(hs.fig,'options');
    options.reduced_loads = get(hs.reduce,'value');
    
    % scaling/offsets
    for lc = 1:length(LC)
        LC(lc).t = LC(lc).ti;
        LC(lc).L = LC(lc).Li;

        for i = 1:length(LC(lc).Lcomps)
            LC(lc).L(:,i) = LC(lc).scale(i)*LC(lc).Li(:,i) + LC(lc).offset(i);
        end
    end
    
    switch options.reduced_loads
        case 1 % full load-time series 
            % (reset)
            
        case 2 % reduce to turning points (peak/valleys)
            LC = reduce_to_turning_points(LC,0);
            
        case 3 % Race track filter 5%
            LC = reduce_to_turning_points(LC,0.05);
            
        case 4 % Race track filter 10%
            LC = reduce_to_turning_points(LC,0.1);
            
        case 5 % Race track filter 20%
            LC = reduce_to_turning_points(LC,0.2);
            
        case 6 % Race track filter 30%
            LC = reduce_to_turning_points(LC,0.3);
            
        case 7 % Race track filter 40%
            LC = reduce_to_turning_points(LC,0.4);
            
        case 8 % single cycle DEL
            for lc = 1:length(LC)
                [~,n_comps] = size(LC(lc).L);
                t = linspace(0,10,60);
                [~,DEL,AVG] = calc_LC_DELs(LC(lc),1);
                LC(lc).t = t;
                LC(lc).L = zeros(60,n_comps,'single');
                for c = 1:n_comps
                    LC(lc).L(:,c) = AVG(c) + DEL(c)/2 * sin(2*pi*t/10);
                end

            end
            
    end
    
    % update no. time steps
    options.n_LCs  = length(LC);
    for lc = 1:length(LC)
        options.n_step(lc) = size(LC(1).L,1);
    end
    
    setappdata(hs.fig,'LC',LC);
    setappdata(hs.fig,'options',options);
    update_gui();
    
end

function cb_selectLoads(~,~)
    
    global hs
    
    if exist('last_folder.mat','file')
        load last_folder.mat
    else
        last_folder = '';
    end
    
    [filename,filepath,~] = uigetfile({'*.xls;*.xlsx'},'Please select loads file',[last_folder '\loads.xlsx']);

    if ~isnumeric(filename)
        last_folder = filepath;
        try
            save('last_folder.mat','last_folder');
        catch
            % only write if possible. 
        end
        loads_file = [filepath filename];
        set(hs.edit,'string',loads_file);
        cb_read_loads();
    end
end

function cb_read_loads(~,~)

    global hs
    
    options = getappdata(hs.fig,'options');
    loads_file = get(hs.edit,'string');

    if ~isempty(loads_file)
        
        options.files.work_folder = fileparts(loads_file);
        options.files.loads_file  = loads_file;
        setappdata(hs.fig,'options',options);

        try
            LC = readXLSloads(loads_file);
            
            set(hs.reduce,'value',1)
            setappdata(hs.fig,'LC',LC);
            setappdata(hs.fig,'options',options);
            
            cb_reduce();
            
            setappdata(hs.fig,'selectedLC',1);
            update_gui();
        catch
            errordlg('Loads file not read correctly. Please try again.','Error');
        end
    end
    
end

function cb_cancel(~,~)

    global hs
    uiresume(hs.fig);
    close(hs.fig);

end

function cb_ok(~,~)

    global hs
    hs.ok_pressed = true;
    uiresume(hs.fig);
    
end

