function set_current_popup_string(handle,string)
    
    string = lower(string);
    list = lower(get(handle,'String'));
    value = find(ismember(list,string));
    
    set(handle,'value',value);
    
end
