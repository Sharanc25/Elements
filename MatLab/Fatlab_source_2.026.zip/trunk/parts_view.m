function ifaces = parts_view(face_table,elem_table,show_parts)%#codegen

ifaces = [];
face_elems  = face_table(:,5);
all_mat_nos = unique(elem_table(:,3));

for i = 1:length(show_parts)
    
    if show_parts(i)
        mat_no     = all_mat_nos(i);
        show_elems = elem_table(elem_table(:,3)==mat_no,1);
        ifaces = [ifaces; find(ismember(face_elems,show_elems))];
    end
end

% coder -build parts_view.prj
