function ifaces = section_view(face_table,elem_table,section)%#codegen

ne = size(elem_table,1);
face_elems = face_table(:,5);
show_elems = zeros(ne,1,'single');
j = 0;

for i=1:ne

    ei = elem_table(i,1);     % element number
    ec = elem_table(i,12:14); % element centroid

    switch section

        case 2 %X>0
            if ec(1) >= 0
                j = j+1;
                show_elems(j) = ei;
            end

        case 3 %X<0
            if ec(1) <= 0
                j = j+1;
                show_elems(j) = ei;
            end

        case 4 %Y>0
            if ec(2) >= 0
                j = j+1;
                show_elems(j) = ei;
            end

        case 5 %Y<0
            if ec(2) <= 0
                j = j+1;
                show_elems(j) = ei;
            end

        case 6 %Z>0
            if ec(3) >= 0
                j = j+1;
                show_elems(j) = ei;
            end

        case 7 %Z<0
            if ec(3) <= 0
                j = j+1;
                show_elems(j) = ei;
            end
            
    end

end

% clear unused entries
show_elems(show_elems==0) = [];

ifaces = find(ismember(face_elems,show_elems));

% coder -build section_view.prj
