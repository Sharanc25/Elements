function S = fix_repeated_values(S)
% check signal for repeated values and fix if any found.

    n = length(S);

    % too short signal
    if n<3
        return
    end
    
    % in case of repeated values, scale one of them a little 
    for i = 1:n-1
        if S(i)==S(i+1)
            S(i+1) = S(i+1)*0.99999;
        end
    end

end