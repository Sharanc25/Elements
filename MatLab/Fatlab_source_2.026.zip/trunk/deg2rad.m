function radians = deg2rad(degrees)

radians = (pi/180) * degrees;
