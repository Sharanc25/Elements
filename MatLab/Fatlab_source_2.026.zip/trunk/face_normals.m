function normals = face_normals(face_table,node_table,elem_centroids,elem2ei)
% Calculates face normals used for edge detection.

n_faces   = length(face_table);
normals   = zeros(n_faces,3,'single');

for f = 1:n_faces
    
    % current face nodes
    cur_face = face_table(f,1:4);

    % find node coords: p,q,r (p=prev, q=center, r=next)
    p = node_table(cur_face(1),2:4)';
    q = node_table(cur_face(2),2:4)';
    r = node_table(cur_face(3),2:4)';

    % face centroid
    fc = face_table(f,6:8)';
    
    % construct edge vectors
    qp = p-q;
    qr = r-q;

    % unit face normal
    n = cross(qr,qp);
    n = n/norm(n);

    % element centroid
    ei = elem2ei(face_table(f,5));
    ec = elem_centroids(ei,:)';

    % fix normal so it points outwards
    n1 = fc + n;
    n2 = fc - n;
    if norm(n1-ec) < norm(n2-ec)
        n = -n;
    end

    % store
    normals(f,:)   = n';

end

