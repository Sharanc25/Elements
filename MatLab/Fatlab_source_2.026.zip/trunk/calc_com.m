function model_com = calc_com(node_table) %#codegen

    n_nodes = size(node_table,1);
    model_com = single([0 0 0]');
    
    for ni = 1:n_nodes
        p = node_table(ni,2:4)';
        model_com = model_com + p;
    end
    
    model_com = model_com/n_nodes;

end