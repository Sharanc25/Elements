function planes = rotate_planes(n,x,n_planes)

    % setup planes
    planes = zeros(1,3*n_planes,'double');
    x_rot = x;
    
    for j = 1:n_planes
        
        planes(1,(j*3-2):(j*3)) = x_rot';
              
        % rotation angle
        theta = pi*j/n_planes;
        
        % rotation matrix around z-axis
        x_rot = rodrigues_rotate(x,n,theta);
        
    end

end
