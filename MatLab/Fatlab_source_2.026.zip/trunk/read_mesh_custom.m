function [node_table,elem_table,elem_types] = read_mesh_custom(file)
% Read custom geometry export in csv format

    % counts
    n_lines = size(file,1);
    nn = 0;
    ne = 0;
    
    % initialize arrays
    node_table = zeros(n_lines,4,'single');  % nodeno, x,y,z coordinates
    elem_table = zeros(n_lines,11,'single'); % elemno, material no, typeno, up to 8 nodes
    elem_types = zeros(n_lines,1,'uint16');
    
    % scan line by line and extract values
    for i = 1:n_lines

        line_str = file(i,:);
        fields   = strsplit(line_str,','); 
        
        switch fields{1}
            case 'T'  % Element types: ET, no, name
                
                type_name = fields{3};
                type_no   = str2double(fields{2});
                
                switch type_name
                    case 'SOLID186' % hex
                        elem_types(type_no) = 2;

                    case 'SOLID187' % tet
                        elem_types(type_no) = 3;

                    case {'PLANE42','PLANE82','PLANE182','PLANE183'} % planar
                        elem_types(type_no) = 4;

                    case {'SHELL181','SHELL281','SHELL63'} % shells
                        elem_types(type_no) = 5;
                    otherwise
                        error('Error: unsupported element.')
                end
                
                
            case 'N' % Nodes: N, node no, x, y, z
                nn = nn+1;
            
                node_no = str2single(fields{2});
                x = str2single(fields{3});
                y = str2single(fields{4});
                z = str2single(fields{5});

                node_table(nn,1:4) = [node_no x y z];
                
            
            case 'E' % Elements: E, element no., material no., element type no., node i, node j, node k,�, node p
                 
                ne = ne+1;
           
                elem_table(ne,1) = str2single(fields{2});
                elem_table(ne,2) = str2single(fields{3}); % type no.
                elem_table(ne,3) = str2single(fields{4}); % material no = type no
                
                % check type no
                if elem_types(elem_table(ne,2))==2 % hex
                    nodes_per_element = 8;
                else % tet/plane/shell
                    nodes_per_element = 4;
                end
                
                for n = 1:nodes_per_element
                    elem_table(ne,n+3) = str2single(fields{4+n});
                end
                
        end
    
    end
    
    % remove unused entries
    node_table(node_table(:,1)==0,:) = [];
    elem_table(elem_table(:,1)==0,:) = [];
    elem_types(elem_types==0) = [];
    
end

%coder -build read_mesh_simulation.prj