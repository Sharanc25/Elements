function dSeqi = equivalent_stress_bilin(rf,SN)

% get SN curve data
m1     = SN.m1;
m2     = SN.m2;
dSmin  = SN.minS;
dsR2zero = SN.ds2;

% get stress range, mean stress and cycles
dS = rf(1,:);
Sm = rf(2,:);
n  = rf(4,:);

dSeqi = 0;

% damage accumulation
for i = 1:length(dS)

    dSi = double(dS(i));
    Smi = double(Sm(i));
    ni  = double(n(i));
    
    % mean stress corrected dsR2
    dsR2mean = mean_stress(Smi,SN);
    
    % correct stress range to zero mean stress (for later comparison with dsR2@R=-1)
    fm = dsR2mean/dsR2zero;  
    dSi = dSi/fm;
    
    if dSi >= dsR2zero
        dSeqi = dSeqi + dSi^m1*ni;
    elseif dSi >= dSmin
        dSeqi = dSeqi + ( (dSi^m2) * (dsR2zero^(m1-m2))  )*ni;
    else % dSi < dSmin
         % do nothing (dSeqi = dSeqi + 0)
    end
   
end
