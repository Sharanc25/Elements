function rf = rainflow_full(S) %#codegen
% Rainflow cycle counting from  
% Amzallag et al. "Standardization of the rainflow counting method 
% for fatigue analysis", Int. J. Fatigue, 16, pp. 287-293, 1993:
% - read in 4 successive points, S1, S2, S3 and S4
% - calculate 3 possible ranges from those, dS1, dS2 and dS3
% - if dS2 is smaller than the neighbours it is extracted and S2+S3 deleted
% - the remaining parts are joined and the process repeats
% - residual cycles are treated by duplicating the signal and re-running


% break if signal is flat
if max(S) == min(S)
    rf = single([0; 0; 0; 0; 0]);
    return;
end

% check that S is column vector
if ~size(S,1)>1
    error('S must be a column vector');
end

% initialize output arrays
n = length(S);
Ni = zeros(1,n,'single');
dS = zeros(1,n,'single');
Sm = zeros(1,n,'single');
c = 1;

% run twice (second run to treat residue)
for m = 1:2
    
    i = 1;
    j = 1;

    while ~(i+3>length(S))

        % read in 4 successive points
        S1 = S(i);
        S2 = S(i+1);
        S3 = S(i+2);
        S4 = S(i+3);

        % calculate range of those
        dS1 = abs(S2-S1);
        dS2 = abs(S3-S2);
        dS3 = abs(S4-S3);

        % extract center range, if smaller or equal
        if dS2 <= dS1 && dS2 <= dS3

            % store cycle
            Ni(c) = 1;
            dS(c) = dS2;
            Sm(c) = (S2 + S3)/2;
            c = c+1;
            
            % joining signal
            for k=i+2:-1:j+2
                S(k) = S(k-2);
            end

            j = j+2;
            i = j;

        else
            i = i+1;
        end

    end
    
    % duplicate residual signal and run again
    res = S(j:end);
    S = [res; res];

end

% remove unused array entries
dS(c:end) = [];
Sm(c:end) = [];
Ni(c:end) = [];

% assemble rf array
% rf(1,1) = range(S);
% rf(2,1) = mean(S);
% rf(3,1) = range(S);
% rf(4,1) = 1;
% rf(5,1) = range(S);
rf = [dS; Sm; dS; Ni; dS];

% coder -build rainflow_full.prj