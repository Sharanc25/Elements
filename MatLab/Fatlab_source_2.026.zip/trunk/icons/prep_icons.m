function icons = prep_icons
    close all;

    h.fig = figure;
    
    h.tb  = findall(h.fig,'tag','FigureToolBar');

    h.tbb = findall(h.tb); 
    h.toolbar.plott_on    = h.tbb(2);
    h.toolbar.plott_off   = h.tbb(3);
    h.toolbar.legend      = h.tbb(4);
    h.toolbar.colorbar    = h.tbb(5);
    h.toolbar.link        = h.tbb(6);
    h.toolbar.brush       = h.tbb(7);
    h.toolbar.data_cursor = h.tbb(8);
    h.toolbar.rotate      = h.tbb(9);
    h.toolbar.pan         = h.tbb(10);
    h.toolbar.zoom_out    = h.tbb(11);
    h.toolbar.zoom_in     = h.tbb(12);
    h.toolbar.edit_plot   = h.tbb(13);
    h.toolbar.print       = h.tbb(14);
    h.toolbar.save        = h.tbb(15);
    h.toolbar.open        = h.tbb(16);
    h.toolbar.new         = h.tbb(17);
    
    icons.new    = h.toolbar.new.CData;
    icons.open   = h.toolbar.open.CData;
    icons.save   = h.toolbar.save.CData;
    icons.select = h.toolbar.edit_plot.CData;
    icons.rotate = h.toolbar.rotate.CData;
    
    
    cameratoolbar
    h.ctb  = findall(h.fig,'tag','CameraToolBar');
    h.ctbb = findall(h.ctb);
    
    icons.light = h.ctbb(6).CData;
    icons.cs    = h.ctbb(8).CData;
    icons.orbit = h.ctbb(11).CData;
        
    % load external icon files
    icons.help = imread(fullfile('book.png'));
    icons.wire_frame = imread(fullfile('wire_frame.png'));
    icons.mouse_3d = imread(fullfile('3d_mouse.png'));
    icons.elements = imread(fullfile('elements.png'));    
    icons.element_numbers = imread(fullfile('element_numbers.png'));    
    icons.element_borders = imread(fullfile('element_borders.png'));    
    icons.part_colors = imread(fullfile('part_colors.png'));    
    icons.nodes = imread(fullfile('nodes.png'));    
    icons.nodes2 = imread(fullfile('nodes2.png'));    
    icons.node_numbers = imread(fullfile('node_numbers.png'));    
    icons.hot = imread(fullfile('hot.png'));
    icons.select_single = imread(fullfile('select_single.png'));
    icons.select_multi = imread(fullfile('select_multi.png'));
    
    icons.popup_model = imread(fullfile('popup_model.png'));
    icons.popup_graph = imread(fullfile('popup_graph.png'));
    
    icons.black_white = imread(fullfile('black_white.png'));
    
    % blue arrow
    icons.probe = icons.select;
    icons.probe(:,:,1) = icons.select(:,:,1)*0.5;
    
    % blue rotate button
    icons.rotate2 = icons.rotate;
    icons.rotate2(:,:,1) = icons.rotate2(:,:,1)*0.5;
    
    % view directions
    views = {'Left','Front','Right','Back','Top','Bottom','3D'};
    for i = 1:length(views)
        icons.view{i} = imread(fullfile(['view_' views{i} '.png']));
    end
    icons.view_names = views;
    
    save('icon_data.mat','icons');
    !copy icon_data.mat ..
    close all;