function generate_loads_file()
% Generates a loads file for Fatlab by reading output files from other programs.
% Currently supported formats:
%   NREL FAST v8
%   Simis Ashes 2.3.1
%   Comma-separated files
%   Tab-seperated data files

close all;
grey = [0.941176 0.941176 0.941176];
h.f  = figure('name','Generat loads file','menu','none','NumberTitle','off','units','characters','position', [4 10 250 55],'color',grey,'toolbar','none'); 
center_gui(h.f);









end