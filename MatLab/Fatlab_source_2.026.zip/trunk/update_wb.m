function update_wb(from,to,frac,hwb)

    inc = to-from;
    wfrac = from + frac*inc;
    waitbar(wfrac,hwb);
    
end