function [SN,options] = setup_SNcurve(SN,options,model)
% Setup SN curve, mean stress handling and analysis options.

    global hs
    
    hs.fig = figure('name','SN curve setup','NumberTitle','off','units','characters','position', [5 2.5 250 55.5],'color',...
        [0.941176 0.941176 0.941176],'toolbar','figure','menu','none','windowstyle','modal','WindowKeyPressFcn',@ok_cancel,'Resize','off');
    change_icon(hs.fig,'icon.png');
    center_gui(hs.fig);
    
    setappdata(hs.fig,'model',model);
    setappdata(hs.fig,'SN',SN);
    setappdata(hs.fig,'options',options);
        
    % panels
    hs.dbpan = uipanel('title','Database','units','characters','pos',[2 35 40 20]);
    hs.snpan = uipanel('title','SN curve','units','characters','pos',[43 35 105 20]);
    hs.mpan  = uipanel('title','Mean stress','units','characters','pos',[149 35 48 20]);
    hs.apan  = uipanel('title','Analysis options','units','characters','pos',[198 35 50 20]);
    
    % db panel 
    SN_db_names = {SN.name};
    hs.list   = uicontrol('Style','list','string',SN_db_names,'units','characters','pos',[2 4.5 35 14],'parent',hs.dbpan,'callback',@selectSN,'backgroundcolor','w');
    set(hs.list,'value',options.selectedSN);
    hs.NewSN  = uicontrol('Style','pushbutton','string','New','units','characters','pos',      [2  2.5 11 1.65],'parent',hs.dbpan,'callback',@NewSN);
    hs.LoadSN = uicontrol('Style','pushbutton','string','Load','units','characters','pos',     [14 2.5 11 1.65],'parent',hs.dbpan,'callback',@LoadSN);
    hs.SaveSN = uicontrol('Style','pushbutton','string','Save','units','characters','pos',     [26 2.5 11 1.65],'parent',hs.dbpan,'callback',@SaveSN);
    hs.DupSN  = uicontrol('Style','pushbutton','string','Duplicate','units','characters','pos',[14 0.5 11 1.65],'parent',hs.dbpan,'callback',@DupSN);
    hs.DelSN  = uicontrol('Style','pushbutton','string','Delete','units','characters','pos',   [2  0.5 11 1.65],'parent',hs.dbpan,'callback',@DelSN);
    

    % plot axes
    hs.SNplot  = axes('units','characters','position',[15 4 110 27]); %[left bottom width height]
    hs.haigh   = axes('units','characters','position',[143 4 100 27]);
    
    % SN panel
    top = get(hs.snpan,'pos');
    top = top(4)-2;    
    b = top-4-[0 2 4 6 8 10 12];
    
    hs.sn.txt   = uicontrol('Style','text','String','SN curve name:','units','characters','pos',  [2  top-1.2 30 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.name  = uicontrol('Style','edit','string',SN(options.selectedSN).name,'units','characters','pos',[35 top-1.6 30 1.6],'parent',hs.snpan,'backgroundcolor','w','horizontalalignment','left','callback',@cb_renameSN);
    
    hs.sn.m1    = uicontrol('Style','edit','string','3','units','characters','pos',[35 b(1)-.6 12 1.6],'parent',hs.snpan,'callback',@cb_custom,'horizontalalignment','right','backgroundcolor','w');
    hs.sn.txt   = uicontrol('Style','text','String','Primary slope, m1:','units','characters','pos',[2 b(1)-.2 23 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.m2    = uicontrol('Style','edit','string','5','units','characters','pos',[35 b(2)-.6 12 1.6],'parent',hs.snpan,'callback',@cb_custom,'horizontalalignment','right','backgroundcolor','w');
    hs.sn.txt   = uicontrol('Style','text','String','Secondary slope, m2:','units','characters','pos',[2 b(2)-.2 23 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.txt   = uicontrol('Style','text','String','MPa','units','characters','pos',[48 b(3)-.2 23 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.ds1   = uicontrol('Style','edit','string','125','units','characters','pos',[35 b(3)-.6 12 1.6],'parent',hs.snpan,'callback',@cb_custom,'horizontalalignment','right','backgroundcolor','w');
    hs.sn.txt   = uicontrol('Style','text','String','Fatigue strength, dsR1:','units','characters','pos',[2 b(3)-.2 23 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.txt   = uicontrol('Style','text','String','cycles','units','characters','pos',[48 b(4)-.2 23 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.N1    = uicontrol('Style','edit','string','2000000','units','characters','pos',[35 b(4)-.6 12 1.6],'parent',hs.snpan,'callback',@cb_custom,'horizontalalignment','right','backgroundcolor','w');
    hs.sn.txt   = uicontrol('Style','text','String','Associated cycles, NR1:','units','characters','pos',[2 b(4)-.2 25 1],'parent',hs.snpan,'horizontalalignment','left');
    
    hs.sn.txt   = uicontrol('Style','text','String','MPa','units','characters','pos',[48 b(5)-.2 5 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.ds2   = uicontrol('Style','edit','string','99','units','characters','pos',[35 b(5)-.6 12 1.6],'parent',hs.snpan,'callback',@cb_custom,'horizontalalignment','right','backgroundcolor','w');
    hs.sn.txt   = uicontrol('Style','text','String','Knee point stress range, dsR2:','units','characters','pos',[2 b(5)-.2 30 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.txt   = uicontrol('Style','text','String','cycles','units','characters','pos',[48 b(6)-.2 8 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.N2    = uicontrol('Style','edit','string','1E7','units','characters','pos',[35 b(6)-.6 12 1.6],'parent',hs.snpan,'callback',@cb_custom,'horizontalalignment','right','backgroundcolor','w');
    hs.sn.txt   = uicontrol('Style','text','String','Knee point cycles, NR2:','units','characters','pos',[2 b(6)-.2 23 1],'parent',hs.snpan,'horizontalalignment','left');
    
    hs.sn.txt   = uicontrol('Style','text','String','Comments:','units','characters','pos',  [2  b(7)-0.2 30 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.comt  = uicontrol('Style','edit','string','','units','characters','pos',[35 b(7)-0.6 60 1.6],'parent',hs.snpan,'backgroundcolor','w','horizontalalignment','left','callback',@cb_custom);
    
    r2 = 60;
    hs.sn.txt   = uicontrol('Style','text','String','MPa','units','characters','pos',[r2+36 b(1)-.2 5 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.minS  = uicontrol('Style','edit','string','0','units','characters','pos',[r2+25 b(1)-.6 10 1.6],'parent',hs.snpan,'callback',@cb_custom,'horizontalalignment','right','backgroundcolor','w');
    hs.sn.txt   = uicontrol('Style','text','String','Min cut-off:','units','characters','pos',[r2+2 b(1)-.2 23 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.txt   = uicontrol('Style','text','String','MPa','units','characters','pos',[r2+36 b(2)-.2 5 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.maxS  = uicontrol('Style','edit','string','1000','units','characters','pos',[r2+25 b(2)-.6 10 1.6],'parent',hs.snpan,'callback',@cb_custom,'horizontalalignment','right','backgroundcolor','w');
    hs.sn.txt   = uicontrol('Style','text','String','Max cut-off:','units','characters','pos',[r2+2 b(2)-.2 23 1],'parent',hs.snpan,'horizontalalignment','left');
    hs.sn.gf    = uicontrol('Style','edit','string','1.35','units','characters','pos',                       [r2+25 b(3)-0.6 10 1.6],'callback',@cb_options,'horizontalalignment','right','backgroundcolor','w','parent',hs.snpan);
    hs.sn.gftxt = uicontrol('Style','text','String','Partial safety factor:','units','characters','pos',     [r2+2  b(3)-0.2 23 1],'horizontalalignment','left','parent',hs.snpan);
    
    hs.sn.Dal   = uicontrol('Style','edit','string','1.00','units','characters','pos',                       [r2+25 b(4)-0.6 10 1.6],'callback',@cb_options,'horizontalalignment','right','backgroundcolor','w','parent',hs.snpan);
    hs.sn.Dtxt  = uicontrol('Style','text','String','Allowable damage:','units','characters','pos',          [r2+2  b(4)-0.2 23 1],'horizontalalignment','left','parent',hs.snpan);
    
    % mean stress panel
	b = top-1-[0 2 4 6 8 10 12];
    hs.mean.txt      = uicontrol('Style','text','String','Mean stress mode:','units','characters','pos',[2 b(1)-.2 22 1],'parent',hs.mpan,'horizontalalignment','left');
    hs.mean.mode     = uicontrol('Style','popupmenu','string',{'None' 'Linear' 'Bilinear' 'Soderberg' 'Modified Goodman' 'Gerber parabola' 'Smith-Watson-Topper' '60% Compression' 'IIW low RS', 'IIW medium RS' 'FKM'},'units','characters','pos',[25 b(1) 20 1],'parent',hs.mpan,'callback',@cb_mean,'backgroundcolor','w');
    hs.mean.txt      = uicontrol('Style','text','String','Mean stress sensitivity, M:','units','characters','pos',[2 b(2)-.2 34 1],'parent',hs.mpan,'horizontalalignment','left');
    hs.mean.M        = uicontrol('Style','edit','string','0.25','units','characters','pos',[35 b(2)-.6 10 1.6],'parent',hs.mpan,'callback',@cb_mean,'horizontalalignment','right','backgroundcolor','w');
    hs.mean.txt      = uicontrol('Style','text','String','Yield strength,Re: [MPa]','units','characters','pos',[2 b(3)-.2 34 1],'parent',hs.mpan,'horizontalalignment','left');
    hs.mean.Re       = uicontrol('Style','edit','string','235','units','characters','pos',[35 b(3)-.6 10 1.6],'parent',hs.mpan,'callback',@cb_mean,'horizontalalignment','right','backgroundcolor','w');
    hs.mean.txt      = uicontrol('Style','text','String','Tensile strength, Rm: [MPa]','units','characters','pos',[2 b(4)-.2 34 1],'parent',hs.mpan,'horizontalalignment','left');
    hs.mean.Rm       = uicontrol('Style','edit','string','370','units','characters','pos',[35 b(4)-.6 10 1.6],'parent',hs.mpan,'callback',@cb_mean,'horizontalalignment','right','backgroundcolor','w');
    hs.mean.yield    = uicontrol('style','checkbox','string','Observe yield-lines','units','characters','pos', [2 b(5) 40 1],'value',0,'parent',hs.mpan,'callback',@cb_mean);
    hs.mean.comp     = uicontrol('style','checkbox','string','Extrapolate in compression','units','characters','pos', [2 b(6) 40 1],'value',0,'parent',hs.mpan,'callback',@cb_mean);

    % analysis options panel
    l1 = 22; l2 =28; w1 =24; w2 = 18;
    hs.txt         = uicontrol('Style','text','String','Fatigue stress:','units','characters','pos',            [2  b(1) 23 1],'parent',hs.apan,'horizontalalignment','left');
    hs.stress_mode = uicontrol('Style','popupmenu','string',options.stresses,'units','characters','pos',        [l1 b(1)+0.2 w1 1],'parent',hs.apan,'callback',@cb_options,'backgroundcolor','w');
    hs.txt         = uicontrol('Style','text','String','Cycle counter:','units','characters','pos',             [2  b(2) 23 1],'parent',hs.apan,'horizontalalignment','left');
    hs.cycle_count = uicontrol('Style','popupmenu','string',{'Reservoir' 'Rainflow full' 'Rainflow half' 'Single cycle'},'units','characters','pos',[l1 b(2)+0.2 w1 1],'parent',hs.apan,'callback',@cb_options,'backgroundcolor','w');
    %'Single cycle LC   ' 'Single cycle MCC  ' 'Single cycle MRH  '
    hs.txt         = uicontrol('Style','text','String','Multiaxial criterion:','units','characters','pos',         [2  b(3) 23 1],'parent',hs.apan,'horizontalalignment','left');
    hs.multi_crit  = uicontrol('Style','popupmenu','string',...
        {'Normal stress  '},'units','characters','pos',[l1 b(3)+0.2 w1 1],'parent',hs.apan,'callback',@cb_options,'backgroundcolor','w','Enable','off');
       %'Modified shear ','IIW equivalent ','Findley        ','Matake         ','Dang Van       ','Sines          ','Papuga PCr     '                                                                        
    
    hs.txt         = uicontrol('Style','text','String','Normal search planes:','units','characters','pos',      [2  b(4) 23 1],'parent',hs.apan,'horizontalalignment','left');
    hs.nplanes     = uicontrol('Style','edit','string','0','units','characters','pos',                          [l2 b(4)-0.4 w2 1.6],'parent',hs.apan,'callback',@cb_options,'backgroundcolor','w','horizontalalignment','right','Enable','off');
    hs.txt         = uicontrol('Style','text','String','Inclined search planes:','units','characters','pos',    [2  b(5) 23 1],'parent',hs.apan,'horizontalalignment','left');
    hs.niplanes    = uicontrol('Style','edit','string','1','units','characters','pos',                          [l2 b(5)-0.4 w2 1.6],'parent',hs.apan,'callback',@cb_options,'backgroundcolor','w','horizontalalignment','right','Enable','off');
    hs.txt         = uicontrol('Style','text','String','Multiaxiality parameter k1:','units','characters','pos',[2  b(6) 25 1],'parent',hs.apan,'horizontalalignment','left');
    hs.multi_k1    = uicontrol('Style','edit','string','0.3','units','characters','pos',                        [l2 b(6)-0.4 w2 1.6],'parent',hs.apan,'callback',@cb_options,'backgroundcolor','w','horizontalalignment','right','Enable','off');
    hs.txt         = uicontrol('Style','text','String','Multiaxiality parameter k2:','units','characters','pos',[2  b(7) 25 1],'parent',hs.apan,'horizontalalignment','left');
    hs.multi_k2    = uicontrol('Style','edit','string','1.0','units','characters','pos',                        [l2 b(7)-0.4 w2 1.6],'parent',hs.apan,'callback',@cb_options,'backgroundcolor','w','horizontalalignment','right','Enable','off');
    
    hs.ok          = uicontrol('Style','pushbutton','string','Ok','units','characters','pos',[24 1 20 2],'callback',@cb_ok,'parent',hs.apan);
    hs.cancel      = uicontrol('Style','pushbutton','string','Cancel','units','characters','pos',[2 1 20 2],'callback',@cb_cancel,'parent',hs.apan);
    
    hs.ok_pressed = false;
    update_gui();
    uicontrol(hs.ok)
    uiwait(hs.fig);
    
    if hs.ok_pressed
        SN      = getappdata(hs.fig,'SN');
        options = getappdata(hs.fig,'options');  
        close(hs.fig);
    end
    
end

function ok_cancel(~,event)

    if strcmp(event.Key,'escape')
        cb_cancel();
    elseif strcmp(event.Key,'return')
        %cb_ok(); % must execute local (e.g. editbox) callbacks first before closing figure!
    end

end

% SN database
function cb_renameSN(~,~)

    global hs
    options = getappdata(hs.fig,'options');
    allSN   = getappdata(hs.fig,'SN');
    
    allSN(options.selectedSN).name = get(hs.sn.name,'string');
    set(hs.list,'string',{allSN.name});
        
    setappdata(hs.fig,'SN',allSN);
    setappdata(hs.fig,'options',options);

end

function NewSN(~,~)
    warndlg('Synthetic SN curve generator. Not finished yet.')
end

function DupSN(~,~)
    
    global hs
    options = getappdata(hs.fig,'options');
    allSN   = getappdata(hs.fig,'SN');
    
    allSN(end+1) = allSN(options.selectedSN);
    options.selectedSN = length(allSN);
    allSN(options.selectedSN).name = get(hs.sn.name,'string');
    set(hs.list,'string',{allSN.name},'value',options.selectedSN);
    
    setappdata(hs.fig,'SN',allSN);
    setappdata(hs.fig,'options',options);
    
end

function LoadSN(~,~)
    
    global hs
    options = getappdata(hs.fig,'options');
    
    [filename,filepath,~] = uigetfile('*.mat','Load SN database file',[options.files.work_folder '\SNdb.mat']);
    
    if ~isnumeric(filename)
        load([filepath filename])
        options.selectedSN = 1;
        set(hs.list,'string',{SN.name},'value',1);
        setappdata(hs.fig,'SN',SN);
        setappdata(hs.fig,'options',options);
        
        selectSN();
        
    end
    
end

function DelSN(~,~)

    global hs
    options = getappdata(hs.fig,'options');
    allSN   = getappdata(hs.fig,'SN');
    
    if options.selectedSN>1
        allSN(options.selectedSN) = [];
        options.selectedSN = options.selectedSN - 1;
        set(hs.list,'string',{allSN.name},'value',options.selectedSN);
        
        setappdata(hs.fig,'SN',allSN);
        setappdata(hs.fig,'options',options);
        update_gui();
    end
    
end

function SaveSN(~,~)
    
    global hs
    SN      = getappdata(hs.fig,'SN');
    options = getappdata(hs.fig,'options');
    
    [filename,filepath,~] = uiputfile('*.mat','Save SN database file',[options.files.work_folder '\SNdb.mat']);
    
    if ~isnumeric(filename)
        save([filepath filename],'SN');
    end
    
end

function selectSN(~,~)
    
    global hs
    options = getappdata(hs.fig,'options');
    options.selectedSN = get(hs.list,'value');
    SNnames = get(hs.list,'string');
    set(hs.sn.name,'string',SNnames{options.selectedSN});
    setappdata(hs.fig,'options',options);
    update_gui();
    
end


% gui functions
function update_gui()

    global hs
    allSN   = getappdata(hs.fig,'SN');
    options = getappdata(hs.fig,'options');
    SN      = allSN(options.selectedSN);

    % mean stress
    set(hs.mean.mode,'value',SN.mean_mode);
    set_value(hs.mean.M,SN.M);
    set_value(hs.mean.Re,SN.Re);
    set_value(hs.mean.Rm,SN.Rm);
    set(hs.mean.yield,'value',SN.mean_yield);
    set(hs.mean.comp,'value',SN.mean_comp);
    
    % analysis options
    set_current_popup_string(hs.stress_mode,options.stress_mode);
    set(hs.cycle_count,'value',options.cycle_count);
    set_current_popup_string(hs.multi_crit,options.multi.criterion);
    set_value(hs.sn.gf,SN.gf);
    set_value(hs.nplanes,options.multi.n_planes(1));
    set_value(hs.niplanes,options.multi.n_planes(2));
    set_value(hs.multi_k1,options.multi.k(1));
    set_value(hs.multi_k2,options.multi.k(2));
    
    % SN curve
    set_value(hs.sn.ds1,SN.ds1);
    set_value(hs.sn.ds2,0)
    set_value(hs.sn.N1,SN.N1);
    set_value(hs.sn.N2,SN.N2);
    set_value(hs.sn.m1,SN.m1);
    set_value(hs.sn.m2,SN.m2);
    set_value(hs.sn.maxS,SN.maxS);
    set_value(hs.sn.minS,SN.minS);
    set_value(hs.sn.Dal,SN.Dal);
    set(hs.sn.comt,'string',SN.comments);
    
    cb_options();

end

function cb_custom(~,~,~)

    global hs
    allSN   = getappdata(hs.fig,'SN');
    options = getappdata(hs.fig,'options');

    m1   = get_value(hs.sn.m1);
    m2   = get_value(hs.sn.m2);
    ds1  = get_value(hs.sn.ds1);
    N1   = get_value(hs.sn.N1);
    N2   = get_value(hs.sn.N2);
    minS = get_value(hs.sn.minS);
    maxS = get_value(hs.sn.maxS);
    gf   = get_value(hs.sn.gf);
    Dal  = get_value(hs.sn.Dal);
    comments = get(hs.sn.comt,'string');

    % knee point stress range
    C1 = ds1^m1*N1;
    ds2 = (C1/N2)^(1/m1)/gf;
    set(hs.sn.ds2,'string',num2str(round(ds2)));

    % plot SN curve
    axes(hs.SNplot);
    hold off
    plotSNcurve(ds1,N1,N2,m1,m2,maxS,minS,gf);

    % export SN curve data
    allSN(options.selectedSN).type     = 'custom';
    allSN(options.selectedSN).ds1      = ds1;
    allSN(options.selectedSN).ds2      = ds2;
    allSN(options.selectedSN).gf       = gf;
    allSN(options.selectedSN).Dal      = Dal;
    allSN(options.selectedSN).N1       = N1;
    allSN(options.selectedSN).N2       = N2;
    allSN(options.selectedSN).m1       = m1;
    allSN(options.selectedSN).m2       = m2;
    allSN(options.selectedSN).maxS     = maxS;
    allSN(options.selectedSN).minS     = minS;
    allSN(options.selectedSN).comments = comments;

    setappdata(hs.fig,'SN',allSN);

    % update mean stress plot
    cb_mean();
    
end

function cb_options(~,~)
    
    global hs
    
    options = getappdata(hs.fig,'options');   
    options.stress_mode     = get_pop_str(hs.stress_mode);
    options.multi.k         = [get_value(hs.multi_k1) get_value(hs.multi_k2)];
    options.multi.criterion = get_pop_str(hs.multi_crit);
    
    if strcmp(options.stress_mode,'CP   ')
        
        set(hs.multi_crit,'Enable','on');     
        set(hs.nplanes,   'Enable','on');   
        
        if get(hs.multi_crit,'value')>2 % CP + general multiaxial criteria
            set(hs.niplanes,'Enable','on');   
            set(hs.niplanes,'Enable','on');   
            set(hs.multi_k1,'Enable','on');
            set(hs.multi_k2,'Enable','on');
        
            if get(hs.cycle_count,'value')<5
                set(hs.cycle_count,'value',5);
            end
            
            cycle_counter = get_pop_str(hs.cycle_count);
            options.multi.shear_cycles = cycle_counter(end-4:end); % 'LC ','MCC','MRH'
            
            options.multiaxial = 2;
            
        else % CP + normal stress / IIW eq.
            if get(hs.multi_crit,'value')==1
                set(hs.multi_k1, 'Enable','off');
                set(hs.multi_k2, 'Enable','off');
            else
                set(hs.multi_k1, 'Enable','on');
                set(hs.multi_k2, 'Enable','on');
            end
            
            set(hs.niplanes,'string','1','Enable','off');
            
            if get(hs.cycle_count,'value')>4
                set(hs.cycle_count,'value',4);
            end
            
            options.multiaxial = 1;
            
        end
        
    else % non-CP methods
        
        options.multiaxial = 0;
        set(hs.multi_crit,'Enable','off');
        set(hs.multi_k1,  'Enable','off');
        set(hs.multi_k2,  'Enable','off');
        set(hs.nplanes,   'Enable','off');
        set(hs.niplanes,  'Enable','off');
        
        if get(hs.cycle_count,'value')>4
            set(hs.cycle_count,'value',4);
        end
            
    end
    
    options.multi.n_planes(1)  = get_value(hs.nplanes);
    options.multi.n_planes(2)  = get_value(hs.niplanes);    
    options.cycle_count = get(hs.cycle_count,'value');
    
    cb_custom();
 
    setappdata(hs.fig,'options',options);
    
end

function cb_mean(~,~)
       
    global hs
    allSN   = getappdata(hs.fig,'SN');
    options = getappdata(hs.fig,'options');
    SN      = allSN(options.selectedSN);
    
    sa2 = SN.ds2/2;
    
    mean_mode = get(hs.mean.mode,'value');
    Re = get_value(hs.mean.Re);
    Rm = get_value(hs.mean.Rm);
    M  = get_value(hs.mean.M);
    
    axes(hs.haigh);
    m = round(Re*1.1);
    plot([0 0],[0 Re*1.1],'k'); hold on
    text(0,Re*1.15,'R=-1','HorizontalAlignment','center')
    k = 0.7; plot([0 k*Re],[0 k*Re],'-k'); 
    text(Re*k*1.075,Re*k*1.075,'R=0','HorizontalAlignment','center')
    k = 0.7; plot([0 -k*Re],[0 k*Re],'-k'); 
    text(-Re*k*1.075,Re*k*1.075,'R=-\infty','HorizontalAlignment','center')

    k = 0.7; plot([0 Re],[0 1/3*Re],'-k'); 
    text(Re*1.075,Re*1/3*1.1,'R=0.5','HorizontalAlignment','right')
    
    plot([-Re 0 Re],[0 Re 0],'k-')
    text(15,Re,'Re')
    text(Re,15,'Re')
    text(-Re+5,15,'-Re','horizontalalignment','right')
    title('Mean stress effect');
    axis equal
    xlim([-m m]);
    ylim([0 1.2*m]);
    
    text(10,sa2*1.15,'\sigma_a^{R=-1}','HorizontalAlignment','left','VerticalAlignment','bottom')
    text(0.03,0.95,{['Re = ' num2str(Re) 'MPa'],['Rm = ' num2str(Rm) 'MPa']},'VerticalAlignment','top','units','normalized','fontsize',9)
    xlabel('Mean stress \sigma_m [MPa]')
    ylabel('Stress amplitude \sigma_a [MPa]')

    % export
    allSN(options.selectedSN).mean_mode = mean_mode;
    allSN(options.selectedSN).M  = M;
    allSN(options.selectedSN).Re = Re;
    allSN(options.selectedSN).Rm = Rm;
    allSN(options.selectedSN).mean_yield = get(hs.mean.yield,'value');
    allSN(options.selectedSN).mean_comp  = get(hs.mean.comp,'value');
    setappdata(hs.fig,'SN',allSN);
    
    % plot
    sm = -m:1:m;
    sa = zeros(length(sm),1);
    for i=1:length(sm)
        ds2 = mean_stress(sm(i),allSN(options.selectedSN));
        sa(i) = ds2/2;
    end
    plot(sm,sa,'r','linewidth',1,'tag','meanplot');
    plot(0,sa2,'ro','markersize',5,'markerfacecolor','w','tag','meanplot');
    hold off
    
end


% helpers
function cb_cancel(~,~)

    global hs
    uiresume(hs.fig);
    close(hs.fig);

end

function cb_ok(~,~)

    global hs
    hs.ok_pressed = true;
    uiresume(hs.fig);
    
end

function str = get_pop_str(hh)
% getCurrentPopupString returns the currently selected 
% string in the popupmenu with handle hh

    list = get(hh,'String');
    val = get(hh,'Value');
    if iscell(list)
       str = list{val};
    else
       str = list(val,:);
    end
end

function num = get_value(h)
    num = str2num(get(h,'string'));
end

function set_value(h,num)
    set(h,'string',num2str(num));
end

