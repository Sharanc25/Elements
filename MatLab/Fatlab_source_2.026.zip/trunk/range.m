function y = range(x)

y = max(x) - min(x);
