function elem_table_out = calc_elem_com(elem_table,node_table,node2ni)
% find & add element CoM to element table

    n_elems = size(elem_table,1);
    elem_table_out = [elem_table zeros(n_elems,3,'single')];
    
    for ei = 1:n_elems
        
        c  = single([0 0 0]'); %CoM
        nn = 0; % no. nodes on element
        for j = 1:8
            n = elem_table(ei,j+3);
            if n>0
                ni = node2ni(n);
                p  = node_table(ni,2:4)';
                c  = c + p;
                nn = nn + 1;
            else
                continue;
            end
        end
        
        elem_table_out(ei,12:14) = c'/nn;
        
    end
    
end

% coder -build calc_elem_com.prj