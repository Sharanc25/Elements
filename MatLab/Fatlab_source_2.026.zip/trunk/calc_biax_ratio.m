function BR = calc_biax_ratio(nodesi,FE,L,options,mode)
% Calculates the biaxiality ratio for nodes

n_nodes = length(nodesi);
n_steps = options.n_step;

BR = zeros(n_nodes,n_steps);

for i = 1:n_nodes

    ni = nodesi(i);
    P  = calc_stress(ni,FE,L,'Pall ',options.multi);
    
    for t = 1:n_steps
        p = sort(abs(P(t,:)));
        BR(i,t) = p(2)/p(3);
    end

end

%if only span is needed?
if strcmp(mode,'span')
    BR = max(abs(BR),[],2);
end
