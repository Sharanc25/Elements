function Sf = calc_stress(ni,FE,Li,stress_mode,multi)
% Calculates fatigue stress-time series, Sf, defined by stress_mode.

% calculate stress tensor over time [n_time_steps x 6]
S = calc_stress_nonlinear_mex(FE(1).load_table,FE(1).ULC_table,FE(1).node_stress(ni).table,Li);

% from this, pick or calculate a fatigue effective stress-time series [n_time_steps x 1]
Sf = calc_fatigue_stress_mex(S,stress_mode,multi);

