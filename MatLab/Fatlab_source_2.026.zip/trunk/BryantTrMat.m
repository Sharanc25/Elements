function A = BryantTrMat(fi)

    cf1=cos(fi(1));
    sf1=sin(fi(1));
    cf2=cos(fi(2));
    sf2=sin(fi(2));
    cf3=cos(fi(3));
    sf3=sin(fi(3));
    
    A=[cf2*cf3                         -cf2*sf3       sf2;
       cf1*sf3+sf1*sf2*cf3  cf1*cf3-sf1*sf2*sf3  -sf1*cf2;
       sf1*sf3-cf1*sf2*cf3  sf1*cf3+cf1*sf2*sf3   cf1*cf2];
   
end